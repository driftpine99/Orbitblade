/* Lichtschwert-Meister — CONFIG zentral anpassbar */
const CONFIG = {
  autoAttackCooldown: 500,
  autoAttackRange: 90,
  autoAttackDamage: 25,
  wirbelCooldown: 8000,
  wirbelRadius: 140,
  wirbelDamageMult: 1.5,
  stossCooldown: 12000,
  stossRange: 200,
  stossPush: 120,
  stossDamage: 30,
  stossWidth: 80,
  playerBaseSpeed: 190,
  playerRadius: 18,
  swordSpinSpeed: 6.0,
  spinDamage: 18,
  spinHitInterval: 120,
  spinRangeBonus: 0,
  enemyTypes: {
    droide: { hp:28, dmg:8, speed:130, radius:14, color:'#8ec8ff', coin:5, xp:12 },
    soldat: { hp:60, dmg:12, speed:95, radius:18, color:'#ff8a3d', coin:10, xp:20 },
    schwer: { hp:125, dmg:20, speed:60, radius:24, color:'#c94a4a', coin:18, xp:30 },
    boss:   { hp:520, dmg:28, speed:70, radius:34, color:'#b84dff', coin:50, xp:80 }
  },
  wave: { baseCount:5, perWave:2.5, hpScale:0.08, dmgScale:0.08, spawnInterval: 700 },
  xpBase: 100, xpPerLevel: 55,
  shop: {
    healPrice:30, healAmount: 999,
    dmgBoostPrice:40, dmgBoostDur:30000,
    shieldPrice:40, shieldDur:10000,
    atkSpeedPrice:50, moveSpeedPrice:50, maxHpPrice:60
  },
  caps: { dmgMult:2.0, speedMult:1.6, rangeMult:1.8, fireRateMult:1.5, maxHpBonus:150 },
  difficulty: {
    padawan:{ playerHp:200, enemySpeed:0.75, enemyCount:0.7, enemyDmg:0.7 },
    jedi:{ playerHp:150, enemySpeed:1.0, enemyCount:1.0, enemyDmg:1.0 },
    meister:{ playerHp:100, enemySpeed:1.2, enemyCount:1.4, enemyDmg:1.25 }
  }
};

const canvas=document.getElementById('game'), ctx=canvas.getContext('2d');
const healthBar=document.getElementById('health-bar'), healthText=document.getElementById('health-text');
const xpBar=document.getElementById('xp-bar'), levelText=document.getElementById('level-text');
const coinText=document.getElementById('coin-text'), waveText=document.getElementById('wave-text');
const overlayStart=document.getElementById('overlay-start'), overlayPause=document.getElementById('overlay-pause');
const overlayShop=document.getElementById('overlay-shop'), overlayLevel=document.getElementById('overlay-levelup');
const overlayOver=document.getElementById('overlay-gameover');
const shopGrid=document.getElementById('shop-grid'), shopCoin=document.getElementById('shop-coin'), shopWave=document.getElementById('shop-wave');
const levelupGrid=document.getElementById('levelup-grid');
const btnWirbel=document.getElementById('btn-wirbel'), btnStoss=document.getElementById('btn-stoss');
const cdWirbel=document.getElementById('cd-wirbel'), cdStoss=document.getElementById('cd-stoss');
const joystickBase=document.getElementById('joystick-base'), joystickStick=document.getElementById('joystick-stick'), joystickZone=document.getElementById('joystick-zone');

let state='menu', difficulty='padawan', raf=0, lastTime=0;
let player, enemies=[], coins=[], particles=[], floats=[];
let swordAngle=0, spinHitTimer=0;
let wave=1, waveEnemiesToSpawn=0, waveSpawned=0, spawnTimer=0;
let shake=0, autoCd=0, wirbelCd=0, stossCd=0;
let dmgBoostUntil=0, shieldUntil=0;
let bonuses={ dmg:0, speed:0, range:0, fireRate:0, maxHp:0 };
let gameWrapShakeX=0, gameWrapShakeY=0;

function resize(){
  const dpr=window.devicePixelRatio||1;
  const w=window.innerWidth, h=window.innerHeight;
  canvas.width=w*dpr; canvas.height=h*dpr;
  canvas.style.width=w+'px'; canvas.style.height=h+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
window.addEventListener('resize',resize); resize();

function newPlayer(){
  const d=CONFIG.difficulty[difficulty];
  const w = canvas.clientWidth || window.innerWidth;
  const h = canvas.clientHeight || window.innerHeight;
  return { x: w/2, y: h/2, vx:0, vy:0, face:0, radius: CONFIG.playerRadius,
    hp:d.playerHp, maxHp:d.playerHp, level:1, xp:0, xpNeed:CONFIG.xpBase, coins:0, hits:0 };
}
player = newPlayer();
window.playerRef = player;
window.addEventListener('load',()=>{ player = newPlayer(); window.playerRef = player; if(state==='menu') updateHUD(); });
// Spieler zentriert – Joystick ausblenden (Bewegung nicht mehr nötig, Schwert rotiert)
joystickZone.style.display='none';
function resetGame(){
  player=newPlayer(); window.playerRef = player; enemies=[]; coins=[]; particles=[]; floats=[];
  wave=1; waveEnemiesToSpawn=0; waveSpawned=0; spawnTimer=0;
  autoCd=0; wirbelCd=0; stossCd=0; dmgBoostUntil=0; shieldUntil=0;
  bonuses={dmg:0,speed:0,range:0,fireRate:0,maxHp:0};
  shake=0; state='playing'; hideAll(); updateHUD(); startWave();
}
function hideAll(){
  overlayStart.classList.add('hidden'); overlayPause.classList.add('hidden');
  overlayShop.classList.add('hidden'); overlayLevel.classList.add('hidden'); overlayOver.classList.add('hidden');
}
function startWave(){
  const d=CONFIG.difficulty[difficulty];
  const count=Math.floor((CONFIG.wave.baseCount + wave*CONFIG.wave.perWave)*d.enemyCount);
  waveEnemiesToSpawn = (wave%5===0)? 1 : count;
  waveSpawned=0; spawnTimer=0;
  waveText.textContent='Welle '+wave;
  if(wave%5===0) spawnBoss(); // boss single
}
function spawnBoss(){
  const e=makeEnemy('boss'); enemies.push(e); waveSpawned=1;
}
function makeEnemy(type){
  const t=CONFIG.enemyTypes[type];
  const scale=1+ (wave-1)*CONFIG.wave.hpScale;
  const dScale=1+ (wave-1)*CONFIG.wave.dmgScale;
  const diff=CONFIG.difficulty[difficulty];
  let x,y; const pad=40; const w=canvas.clientWidth||window.innerWidth,h=canvas.clientHeight||window.innerHeight;
  const side=Math.floor(Math.random()*4);
  if(side===0){x=Math.random()*w;y=-pad}else if(side===1){x=w+pad;y=Math.random()*h}else if(side===2){x=Math.random()*w;y=h+pad}else{x=-pad;y=Math.random()*h}
  return { type, x,y, hp:Math.round(t.hp*scale), maxHp:Math.round(t.hp*scale), dmg:Math.round(t.dmg*dScale*diff.enemyDmg), speed:t.speed*diff.enemySpeed, radius:t.radius, color:t.color, hitCd:0, bossTimer:0 };
}
function randomEnemyType(){
  const r=Math.random();
  if(r<0.5) return 'droide';
  if(r<0.8) return 'soldat';
  return 'schwer';
}

// Input
let moveVec={x:0,y:0}, joystickActive=false, joystickTouchId=null;
let keys={};

function setJoystick(vx,vy){
  moveVec.x=vx; moveVec.y=vy;
  if(vx||vy) player.face=Math.atan2(vy,vx);
  const max=32;
  joystickStick.style.transform=`translate(${vx*max}px,${vy*max}px)`;
}
function handleJoystickTouch(e){
  e.preventDefault();
  const rect=joystickBase.getBoundingClientRect();
  const cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
  for(const t of e.changedTouches){
    if(e.type==='touchstart'){
      if(joystickTouchId===null && t.clientX>rect.left-20 && t.clientX<rect.left+rect.width+20 && t.clientY>rect.top-20 && t.clientY<rect.top+rect.height+20){
        joystickTouchId=t.identifier; joystickActive=true;
      }
    }
  }
  if(joystickTouchId!==null){
    let found=null;
    for(const t of e.touches) if(t.identifier===joystickTouchId) found=t;
    if(found){
      let dx=(found.clientX-cx)/ (rect.width/2), dy=(found.clientY-cy)/(rect.height/2);
      const len=Math.hypot(dx,dy);
      if(len>1){dx/=len;dy/=len}
      setJoystick(dx,dy);
    }
    if(e.type==='touchend' || e.type==='touchcancel'){
      for(const t of e.changedTouches) if(t.identifier===joystickTouchId){
        joystickTouchId=null; joystickActive=false; setJoystick(0,0);
      }
    }
  }
}
joystickZone.addEventListener('touchstart',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchmove',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchend',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchcancel',handleJoystickTouch,{passive:false});
// mouse fallback for joystick
let mouseDown=false;
joystickBase.addEventListener('mousedown',e=>{mouseDown=true; handleMouse(e)});
window.addEventListener('mousemove',e=>{if(mouseDown) handleMouse(e)});
window.addEventListener('mouseup',()=>{if(mouseDown){mouseDown=false;setJoystick(0,0)}});
function handleMouse(e){
  const rect=joystickBase.getBoundingClientRect();
  const cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
  let dx=(e.clientX-cx)/(rect.width/2), dy=(e.clientY-cy)/(rect.height/2);
  const len=Math.hypot(dx,dy); if(len>1){dx/=len;dy/=len}
  setJoystick(dx,dy);
}
window.addEventListener('keydown',e=>{
  keys[e.key.toLowerCase()]=true;
  if(e.key==='1') doWirbel();
  if(e.key==='2') doStoss();
  if(e.key==='Escape' && state==='playing') pauseGame();
  if(e.key==='Escape' && state==='paused') resumeGame();
});
window.addEventListener('keyup',e=> keys[e.key.toLowerCase()]=false);
canvas.addEventListener('click',e=>{
  if(state!=='playing') return;
  // optional manual attack: set autoCd to 0 and trigger
  if(autoCd<=0) tryAutoAttack();
});
canvas.addEventListener('touchstart',e=>{
  // prevent scroll, but allow buttons: only prevent if not on button
  if(e.target.closest('button')) return;
  e.preventDefault();
},{passive:false});

// Pause
function pauseGame(){ if(state!=='playing') return; state='paused'; overlayPause.classList.remove('hidden'); }
function resumeGame(){ if(state!=='paused') return; state='playing'; overlayPause.classList.add('hidden'); lastTime=performance.now(); }
document.getElementById('pause-btn').addEventListener('click',pauseGame);
document.getElementById('resume-btn').addEventListener('click',resumeGame);
document.getElementById('restart-btn-pause').addEventListener('click',()=>{ resetGame(); });
document.getElementById('restart-btn').addEventListener('click',()=>{ overlayOver.classList.add('hidden'); document.getElementById('overlay-start').classList.remove('hidden'); state='menu'; });
document.getElementById('start-btn').addEventListener('click',resetGame);
document.querySelectorAll('.diff-btn').forEach(b=>{
  b.addEventListener('click',()=>{
    document.querySelectorAll('.diff-btn').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); difficulty=b.dataset.diff;
  });
});

// Specials
function doWirbel(){
  if(state!=='playing' || wirbelCd>0) return;
  wirbelCd=CONFIG.wirbelCooldown;
  const dmg=Math.round(CONFIG.autoAttackDamage*(1+bonuses.dmg)*CONFIG.wirbelDamageMult * (dmgBoostUntil>Date.now()?2:1));
  const r=CONFIG.wirbelRadius*(1+bonuses.range*0.5);
  let hit=false;
  for(const en of enemies){
    if(Math.hypot(en.x-player.x,en.y-player.y) < r + en.radius){
      en.hp-=dmg; hit=true; spawnParticles(en.x,en.y,en.color,8); pushFloat(en.x,en.y-20,'-'+dmg,'#ffcc33');
    }
  }
  spawnParticles(player.x,player.y,'#ffcc33',14);
  if(hit) shake=8;
}
function doStoss(){
  if(state!=='playing' || stossCd>0) return;
  stossCd=CONFIG.stossCooldown;
  const dir=player.face;
  const dmg=Math.round(CONFIG.stossDamage*(1+bonuses.dmg)*(dmgBoostUntil>Date.now()?2:1));
  const range=CONFIG.stossRange, width=CONFIG.stossWidth;
  for(const en of enemies){
    const dx=en.x-player.x, dy=en.y-player.y;
    const proj = dx*Math.cos(dir)+ dy*Math.sin(dir);
    const perp = Math.abs(-dx*Math.sin(dir)+ dy*Math.cos(dir));
    if(proj>0 && proj<range+en.radius && perp < width/2 + en.radius){
      en.hp-=dmg;
      en.x += Math.cos(dir)*CONFIG.stossPush;
      en.y += Math.sin(dir)*CONFIG.stossPush;
      spawnParticles(en.x,en.y,'#6ec8ff',6);
      pushFloat(en.x,en.y-18,'-'+dmg,'#6ec8ff');
    }
  }
  spawnParticles(player.x+Math.cos(dir)*30, player.y+Math.sin(dir)*30,'#6ec8ff',10);
  shake=6;
}
btnWirbel.addEventListener('touchstart',e=>{e.preventDefault();doWirbel()});
btnStoss.addEventListener('touchstart',e=>{e.preventDefault();doStoss()});
btnWirbel.addEventListener('click',doWirbel);
btnStoss.addEventListener('click',doStoss);

// Coins, particles, floats
function dropCoin(x,y, amount){ coins.push({x,y,amount, r:8, taken:false}); }
function spawnParticles(x,y,color,n=6){
  for(let i=0;i<n;i++) particles.push({x,y, vx:(Math.random()-0.5)*240, vy:(Math.random()-0.5)*240, life:0.4+Math.random()*0.3, max:0.6, color, size:2+Math.random()*3});
}
function pushFloat(x,y,text,color){ floats.push({x,y,text,color,life:0.9, vy:-40}); }

// Level up
const UPGRADE_POOL=[
  {id:'dmg', name:'+20% Schaden', desc:'Lichtschwert trifft härter', color:'card-damage', apply:()=>{bonuses.dmg=Math.min(bonuses.dmg+0.2, CONFIG.caps.dmgMult-1)}},
  {id:'hp', name:'+25 Max-Leben', desc:'Mehr Durchhaltevermögen', color:'card-health', apply:()=>{bonuses.maxHp=Math.min(bonuses.maxHp+25, CONFIG.caps.maxHpBonus); player.maxHp+=25; player.hp+=25}},
  {id:'speed', name:'+15% Tempo', desc:'Schneller ausweichen', color:'card-speed', apply:()=>{bonuses.speed=Math.min(bonuses.speed+0.15, CONFIG.caps.speedMult-1)}},
  {id:'range', name:'+20% Reichweite', desc:'Größerer Schlagradius', color:'card-range', apply:()=>{bonuses.range=Math.min(bonuses.range+0.2, CONFIG.caps.rangeMult-1)}},
  {id:'firerate', name:'+10% Angriffstempo', desc:'Schlägt schneller zu', color:'card-firerate', apply:()=>{bonuses.fireRate=Math.min(bonuses.fireRate+0.10, CONFIG.caps.fireRateMult-1)}},
];
function checkLevelUp(){
  while(player.xp >= player.xpNeed){
    player.xp-=player.xpNeed; player.level++; player.xpNeed=Math.round(CONFIG.xpBase + player.level*CONFIG.xpPerLevel);
    triggerLevelUp();
  }
}
function triggerLevelUp(){
  state='levelup';
  const picks=[...UPGRADE_POOL].sort(()=>Math.random()-0.5).slice(0,3);
  levelupGrid.innerHTML='';
  for(const up of picks){
    const capInfo = up.id==='dmg'?`Cap +${Math.round((CONFIG.caps.dmgMult-1)*100)}%` : up.id==='hp'?`Cap +${CONFIG.caps.maxHpBonus}` : up.id==='speed'?`Cap +${Math.round((CONFIG.caps.speedMult-1)*100)}%` : up.id==='range'?`Cap +${Math.round((CONFIG.caps.rangeMult-1)*100)}%`:`Cap +${Math.round((CONFIG.caps.fireRateMult-1)*100)}%`;
    const div=document.createElement('button');
    div.className='levelup-card '+up.color;
    div.innerHTML=`<h3>${up.name}</h3><p>${up.desc}</p><div class="cap">${capInfo}</div>`;
    div.onclick=()=>{
      up.apply(); overlayLevel.classList.add('hidden'); state='playing'; lastTime=performance.now(); updateHUD();
    };
    levelupGrid.appendChild(div);
  }
  overlayLevel.classList.remove('hidden');
}

// Shop
function openShop(){
  state='shop';
  shopWave.textContent=wave;
  shopCoin.textContent='Münzen: '+player.coins;
  renderShop();
  overlayShop.classList.remove('hidden');
}
function renderShop(){
  const items=[
    {name:'Heiltrank', desc:'Leben vollständig heilen', price:CONFIG.shop.healPrice, can: player.coins>=CONFIG.shop.healPrice && player.hp<player.maxHp, buy:()=>{player.hp=player.maxHp;}},
    {name:'Schadens-Boost', desc:'30s doppelter Schaden', price:CONFIG.shop.dmgBoostPrice, can:player.coins>=CONFIG.shop.dmgBoostPrice, buy:()=>{dmgBoostUntil=Date.now()+CONFIG.shop.dmgBoostDur}},
    {name:'Schild', desc:'10s unverwundbar', price:CONFIG.shop.shieldPrice, can:player.coins>=CONFIG.shop.shieldPrice, buy:()=>{shieldUntil=Date.now()+CONFIG.shop.shieldDur}},
    {name:'Angriffstempo +15%', desc:'Permanent', price:CONFIG.shop.atkSpeedPrice, can:player.coins>=CONFIG.shop.atkSpeedPrice && bonuses.fireRate < CONFIG.caps.fireRateMult-1 -1e-9, buy:()=>{bonuses.fireRate=Math.min(bonuses.fireRate+0.15, CONFIG.caps.fireRateMult-1)}},
    {name:'Tempo +10%', desc:'Permanent schneller', price:CONFIG.shop.moveSpeedPrice, can:player.coins>=CONFIG.shop.moveSpeedPrice && bonuses.speed < CONFIG.caps.speedMult-1-1e-9, buy:()=>{bonuses.speed=Math.min(bonuses.speed+0.10, CONFIG.caps.speedMult-1)}},
    {name:'Max-Leben +25', desc:'Permanent', price:CONFIG.shop.maxHpPrice, can:player.coins>=CONFIG.shop.maxHpPrice && bonuses.maxHp < CONFIG.caps.maxHpBonus, buy:()=>{bonuses.maxHp+=25; player.maxHp+=25; player.hp+=25}},
  ];
  shopGrid.innerHTML='';
  for(const it of items){
    const c=document.createElement('div'); c.className='shop-card';
    c.innerHTML=`<h3>${it.name}</h3><p>${it.desc}</p><button ${it.can?'':'disabled'}>${it.price} Münzen</button>`;
    c.querySelector('button').onclick=()=>{
      if(!it.can) return;
      player.coins-=it.price; it.buy(); updateHUD(); renderShop();
    };
    shopGrid.appendChild(c);
  }
  shopCoin.textContent='Münzen: '+player.coins;
}
document.getElementById('shop-continue').addEventListener('click',()=>{
  overlayShop.classList.add('hidden'); wave++; startWave(); state='playing'; lastTime=performance.now();
});

// Auto attack
function tryAutoAttack(){
  const range=CONFIG.autoAttackRange*(1+bonuses.range);
  let best=null, bestD=1e9;
  for(const en of enemies){
    const d=Math.hypot(en.x-player.x,en.y-player.y);
    if(d < range + en.radius && d < bestD){ best=en; bestD=d; }
  }
  if(!best) return false;
  const dmg=Math.round(CONFIG.autoAttackDamage*(1+bonuses.dmg)*(dmgBoostUntil>Date.now()?2:1));
  best.hp-=dmg;
  spawnParticles(best.x,best.y,'#ffec8b',5);
  pushFloat(best.x,best.y-16,'-'+dmg,'#ffec8b');
  // sword swing effect
  particles.push({x:player.x, y:player.y, vx:0,vy:0, life:0.12, max:0.12, color:'#ffec8b', size: range, sword:true, angle: Math.atan2(best.y-player.y, best.x-player.x)});
  autoCd = CONFIG.autoAttackCooldown * (1 - bonuses.fireRate*0.6);
  return true;
}

// Update HUD
function updateHUD(){
  const pct=Math.max(0, player.hp/player.maxHp*100);
  healthBar.style.width=pct+'%';
  healthText.textContent=Math.ceil(player.hp)+' / '+player.maxHp;
  xpBar.style.width=(player.xp/player.xpNeed*100)+'%';
  levelText.textContent='Level '+player.level+' · XP '+player.xp+'/'+player.xpNeed;
  coinText.textContent='💰 '+player.coins;
}

// Game over
function gameOver(){
  state='gameover';
  document.getElementById('gameover-stats').textContent=`Erreicht: Welle ${wave} · Level ${player.level} · Münzen ${player.coins}`;
  overlayOver.classList.remove('hidden');
}

// Loop
function update(dt){
  if(state!=='playing') return;
  // cooldowns
  autoCd-=dt; wirbelCd-=dt; stossCd-=dt;
  if(autoCd<=0) tryAutoAttack();
  // cooldown UI
  const wPct=Math.max(0, 1 - wirbelCd/CONFIG.wirbelCooldown);
  const sPct=Math.max(0, 1 - stossCd/CONFIG.stossCooldown);
  cdWirbel.style.width=(wPct*100)+'%';
  cdStoss.style.width=(sPct*100)+'%';
  btnWirbel.classList.toggle('on-cooldown', wirbelCd>0);
  btnStoss.classList.toggle('on-cooldown', stossCd>0);

  // Spieler fest zentriert – Lichtschwert rotiert permanent
  const w=canvas.clientWidth || window.innerWidth, h=canvas.clientHeight || window.innerHeight;
  player.x = w/2;
  player.y = h/2;
  swordAngle += CONFIG.swordSpinSpeed * (1 + bonuses.fireRate*0.6) * dt/1000;
  if(swordAngle>Math.PI*2) swordAngle-=Math.PI*2;
  player.face = swordAngle;
  // Spin-Treffer (kreisförmig)
  spinHitTimer -= dt;
  if(spinHitTimer<=0){
    spinHitTimer = CONFIG.spinHitInterval;
    const bladeLen = 38 + bonuses.range*22;
    const dmg = Math.round(CONFIG.spinDamage * (1+bonuses.dmg) * (dmgBoostUntil>Date.now()?2:1));
    for(const en of enemies){
      const d = Math.hypot(en.x-player.x, en.y-player.y);
      if(d < bladeLen + en.radius){
        en.hp -= dmg;
        spawnParticles(en.x,en.y,'#ffec8b',4);
        pushFloat(en.x,en.y-16,'-'+dmg,'#ffec8b');
        if(en.hp<=0) continue;
        // leichter Rückstoß
        const ang = Math.atan2(en.y-player.y, en.x-player.x);
        en.x += Math.cos(ang)*8;
        en.y += Math.sin(ang)*8;
      }
    }
    // visueller Spin-Trail
    particles.push({x:player.x, y:player.y, vx:0,vy:0, life:0.14, max:0.14, color:'#ff2d2d', size: bladeLen, sword:true, angle: swordAngle});
  }

  // spawn
  if(wave%5!==0){
    spawnTimer+=dt;
    if(waveSpawned < waveEnemiesToSpawn && spawnTimer > CONFIG.wave.spawnInterval){
      spawnTimer=0; enemies.push(makeEnemy(randomEnemyType())); waveSpawned++;
    }
  }
  // enemies update
  for(const en of enemies){
    const dx=player.x-en.x, dy=player.y-en.y; const d=Math.hypot(dx,dy);
    if(d>1){ en.x+= dx/d * en.speed * dt/1000; en.y+= dy/d * en.speed * dt/1000; }
    // attack if close
    if(d < en.radius + player.radius + 4){
      if(en.hitCd<=0){
        if(Date.now() > shieldUntil){
          player.hp-=en.dmg; shake=6; spawnParticles(player.x,player.y,'#ff4d4d',6);
          if(player.hp<=0){ player.hp=0; updateHUD(); gameOver(); return; }
        }
        en.hitCd=700;
      }
    }
    if(en.hitCd>0) en.hitCd-=dt;
    // boss shockwave
    if(en.type==='boss'){
      en.bossTimer=(en.bossTimer||0)+dt;
      if(en.bossTimer>3000){
        en.bossTimer=0;
        // damage if in ring 80-160
        const dist=Math.hypot(player.x-en.x, player.y-en.y);
        if(dist>70 && dist<170 && Date.now()>shieldUntil){ player.hp-=12; shake=10; }
        spawnParticles(en.x,en.y,'#b84dff',12);
      }
    }
  }
  // remove dead
  for(let i=enemies.length-1;i>=0;i--){
    if(enemies[i].hp<=0){
      const en=enemies[i];
      dropCoin(en.x,en.y, CONFIG.enemyTypes[en.type].coin);
      player.xp+=CONFIG.enemyTypes[en.type].xp;
      spawnParticles(en.x,en.y,en.color,10);
      enemies.splice(i,1);
    }
  }
  checkLevelUp();
  // coins pickup
  for(let i=coins.length-1;i>=0;i--){
    const c=coins[i];
    const d=Math.hypot(c.x-player.x,c.y-player.y);
    if(d<28){ player.coins+=c.amount; pushFloat(c.x,c.y-10,'+'+c.amount+' Münzen','#ffcc33'); coins.splice(i,1); continue; }
    // magnet
    if(d<90){ c.x+=(player.x-c.x)*4*dt/1000; c.y+=(player.y-c.y)*4*dt/1000; }
  }
  // particles
  for(let i=particles.length-1;i>=0;i--){
    const p=particles[i]; p.life-=dt/1000; if(p.life<=0){particles.splice(i,1); continue;}
    if(!p.sword){ p.x+=p.vx*dt/1000; p.y+=p.vy*dt/1000; p.vy+= 300*dt/1000; }
  }
  for(let i=floats.length-1;i>=0;i--){ const f=floats[i]; f.life-=dt/1000; f.y+=f.vy*dt/1000; if(f.life<=0) floats.splice(i,1); }

  // wave clear check
  if(waveSpawned>=waveEnemiesToSpawn && enemies.length===0){
    if(state==='playing') openShop();
  }
  if(shake>0) shake-= dt*0.04;
  updateHUD();
}

function draw(){
  const w=canvas.clientWidth||window.innerWidth,h=canvas.clientHeight||window.innerHeight;
  ctx.clearRect(0,0,w,h);
  let sx=0,sy=0;
  if(shake>0){ sx=(Math.random()-0.5)*shake*2; sy=(Math.random()-0.5)*shake*2; }
  ctx.save(); ctx.translate(sx,sy);
  // — Aufwändiger Hintergrund —
  const bgGrad = ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,Math.max(w,h)*0.85);
  bgGrad.addColorStop(0,'#121d33'); bgGrad.addColorStop(0.55,'#0c1424'); bgGrad.addColorStop(1,'#070b14');
  ctx.fillStyle=bgGrad; ctx.fillRect(0,0,w,h);
  // feine Bodenplatten
  ctx.strokeStyle='rgba(58,74,106,0.18)'; ctx.lineWidth=1;
  for(let x= -40; x<w+40; x+=48){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
  for(let y= -40; y<h+40; y+=48){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
  // diagonales Muster subtil
  ctx.strokeStyle='rgba(58,74,106,0.07)';
  for(let i=-h;i<w+h;i+=80){ ctx.beginPath(); ctx.moveTo(i,0); ctx.lineTo(i+h,h); ctx.stroke(); }
  // zentrale Arena-Plattform
  const platR = Math.min(w,h)*0.36;
  const platGrad = ctx.createRadialGradient(w/2,h/2,platR*0.2,w/2,h/2,platR);
  platGrad.addColorStop(0,'rgba(32,48,78,0.35)'); platGrad.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=platGrad; ctx.beginPath(); ctx.arc(w/2,h/2,platR,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='rgba(86,108,150,0.22)'; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(w/2,h/2,platR,0,Math.PI*2); ctx.stroke();
  ctx.strokeStyle='rgba(86,108,150,0.12)'; ctx.setLineDash([10,10]); ctx.beginPath(); ctx.arc(w/2,h/2,platR*0.72,0,Math.PI*2); ctx.stroke(); ctx.setLineDash([]);
  // äußerer Rand
  ctx.strokeStyle='rgba(28,38,62,0.9)'; ctx.lineWidth=8; ctx.strokeRect(0,0,w,h);
  ctx.strokeStyle='rgba(255,204,51,0.08)'; ctx.lineWidth=1; ctx.strokeRect(2,2,w-4,h-4);
  // Vignette
  const vig = ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*0.4,w/2,h/2,Math.max(w,h)*0.9);
  vig.addColorStop(0,'rgba(0,0,0,0)'); vig.addColorStop(1,'rgba(0,0,0,0.45)');
  ctx.fillStyle=vig; ctx.fillRect(0,0,w,h);
  // coins – aufwändiger
  for(const c of coins){
    ctx.save(); ctx.translate(c.x,c.y);
    ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(0,5,7,3,0,0,Math.PI*2); ctx.fill();
    const g = ctx.createRadialGradient(-2,-2,1,0,0,7);
    g.addColorStop(0,'#ffe98a'); g.addColorStop(0.5,'#ffcc33'); g.addColorStop(1,'#b78f0a');
    ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,7,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle='rgba(122,90,0,0.6)'; ctx.lineWidth=1; ctx.stroke();
    ctx.fillStyle='#7a5a00'; ctx.font='bold 9px system-ui'; ctx.textAlign='center'; ctx.fillText('◈',0,3);
    ctx.restore();
  }
  // enemies – aufwändige Designs
  for(const en of enemies){
    ctx.save(); ctx.translate(en.x,en.y);
    const ang = Math.atan2(player.y-en.y, player.x-en.x);
    ctx.rotate(ang);
    // Schatten
    ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(2, en.radius*0.6, en.radius*0.9, en.radius*0.45,0,0,Math.PI*2); ctx.fill();
    if(en.type==='droide'){
      // Droide: kompakter Körper mit Antenne
      ctx.fillStyle='#1a2a44'; ctx.beginPath(); ctx.roundRect(-en.radius*0.9,-en.radius*0.7,en.radius*1.8,en.radius*1.4,5); ctx.fill();
      ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(0,0,en.radius*0.65,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#0a1220'; ctx.beginPath(); ctx.arc(4,-2,en.radius*0.22,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#ff3b30'; ctx.beginPath(); ctx.arc(5,-2,en.radius*0.11,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle='rgba(255,255,255,0.35)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(0,-en.radius*0.7); ctx.lineTo(0,-en.radius*1.1); ctx.stroke();
      ctx.fillStyle='#ffcc33'; ctx.beginPath(); ctx.arc(0,-en.radius*1.1,2,0,Math.PI*2); ctx.fill();
    } else if(en.type==='soldat'){
      // Soldat: Helm mit Visier
      ctx.fillStyle='#2b3245'; ctx.beginPath(); ctx.roundRect(-en.radius*0.85,-en.radius*0.85,en.radius*1.7,en.radius*1.7,6); ctx.fill();
      ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(0,-2,en.radius*0.62,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#0d1117'; ctx.beginPath(); ctx.roundRect(-en.radius*0.5,-en.radius*0.25,en.radius, en.radius*0.38,3); ctx.fill();
      ctx.fillStyle='rgba(110,200,255,0.75)'; ctx.beginPath(); ctx.roundRect(-en.radius*0.45,-en.radius*0.18,en.radius*0.9, en.radius*0.18,2); ctx.fill();
      ctx.fillStyle='rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.arc(-3,3,2,0,Math.PI*2); ctx.fill();
    } else if(en.type==='schwer'){
      // Schwer: massiv mit Schulterplatten
      ctx.fillStyle='#3a1f1f'; ctx.beginPath(); ctx.roundRect(-en.radius*0.95,-en.radius*0.9,en.radius*1.9,en.radius*1.8,7); ctx.fill();
      ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(0,0,en.radius*0.7,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#1f0f0f'; ctx.beginPath(); ctx.roundRect(-en.radius*0.9,-en.radius*0.5,en.radius*0.4,en.radius*0.9,3); ctx.fill();
      ctx.beginPath(); ctx.roundRect(en.radius*0.5,-en.radius*0.5,en.radius*0.4,en.radius*0.9,3); ctx.fill();
      ctx.fillStyle='rgba(255,255,255,0.15)'; ctx.beginPath(); ctx.arc(-4,-4,en.radius*0.18,0,Math.PI*2); ctx.fill();
    } else { // boss
      const r=en.radius;
      ctx.fillStyle='#2a1a3e'; ctx.beginPath(); ctx.roundRect(-r*0.95,-r*0.95,r*1.9,r*1.9,10); ctx.fill();
      ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(0,0,r*0.75,0,Math.PI*2); ctx.fill();
      // Krone
      ctx.fillStyle='#ffcc33'; ctx.beginPath(); ctx.moveTo(-r*0.6,-r*0.85); ctx.lineTo(-r*0.3,-r*1.05); ctx.lineTo(0,-r*0.85); ctx.lineTo(r*0.3,-r*1.05); ctx.lineTo(r*0.6,-r*0.85); ctx.closePath(); ctx.fill();
      ctx.fillStyle='#0a0f1a'; ctx.beginPath(); ctx.arc(0,2,r*0.22,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#ff3b30'; ctx.beginPath(); ctx.arc(0,2,r*0.11,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle='rgba(255,255,255,0.9)'; ctx.lineWidth=2; ctx.beginPath(); ctx.arc(0,0,r+2,0,Math.PI*2); ctx.stroke();
      ctx.strokeStyle='rgba(184,77,255,0.4)'; ctx.lineWidth=8; ctx.beginPath(); ctx.arc(0,0,r+8,0,Math.PI*2); ctx.stroke();
    }
    ctx.restore();
    // HP-Bar
    const bw=en.radius*2.2, bh=5;
    ctx.fillStyle='rgba(0,0,0,0.55)'; ctx.beginPath(); ctx.roundRect(en.x-bw/2,en.y-en.radius-14,bw,bh,2); ctx.fill();
    ctx.fillStyle=en.type==='boss'?'#ff4d4d':'#3ad07a'; ctx.beginPath(); ctx.roundRect(en.x-bw/2,en.y-en.radius-14,bw*(en.hp/en.maxHp),bh,2); ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,0.15)'; ctx.lineWidth=1; ctx.strokeRect(en.x-bw/2,en.y-en.radius-14,bw,bh);
  }
  // player – aufwändig, zentriert
  ctx.save(); ctx.translate(player.x,player.y);
  // Schatten
  ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(0,16,18,7,0,0,Math.PI*2); ctx.fill();
  // Schild
  if(Date.now()<shieldUntil){ ctx.strokeStyle='rgba(110,200,255,0.95)'; ctx.lineWidth=3; ctx.shadowColor='#6ec8ff'; ctx.shadowBlur=12; ctx.beginPath(); ctx.arc(0,0,player.radius+14,0,Math.PI*2); ctx.stroke(); ctx.shadowBlur=0; }
  if(Date.now()<dmgBoostUntil){ ctx.shadowColor='#ff4d4d'; ctx.shadowBlur=14; }
  // Beine
  ctx.fillStyle='#1a2335'; ctx.beginPath(); ctx.roundRect(-9,8,7,12,3); ctx.fill(); ctx.beginPath(); ctx.roundRect(2,8,7,12,3); ctx.fill();
  ctx.fillStyle='#0f1726'; ctx.beginPath(); ctx.roundRect(-9,18,7,4,2); ctx.fill(); ctx.beginPath(); ctx.roundRect(2,18,7,4,2); ctx.fill();
  // Umhang
  ctx.fillStyle='#141e33'; ctx.beginPath(); ctx.moveTo(-14,-6); ctx.lineTo(-18,14); ctx.lineTo(18,14); ctx.lineTo(14,-6); ctx.closePath(); ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.06)'; ctx.beginPath(); ctx.moveTo(-14,-6); ctx.lineTo(-10,10); ctx.lineTo(-6,-6); ctx.closePath(); ctx.fill();
  // Torso
  ctx.fillStyle='#e8edf5'; ctx.beginPath(); ctx.roundRect(-11,-10,22,20,5); ctx.fill();
  ctx.fillStyle='#c9d3e8'; ctx.beginPath(); ctx.roundRect(-3,-10,6,20,2); ctx.fill();
  ctx.fillStyle='#8a9bb8'; ctx.beginPath(); ctx.rect(-11,-2,22,2); ctx.fill();
  // Arme
  ctx.fillStyle='#d9e2f3'; ctx.beginPath(); ctx.roundRect(-16,-7,6,14,3); ctx.fill(); ctx.beginPath(); ctx.roundRect(10,-7,6,14,3); ctx.fill();
  // Kopf
  ctx.fillStyle='#f0d6b8'; ctx.beginPath(); ctx.arc(0,-16,9,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#d9b99a'; ctx.beginPath(); ctx.arc(0,-13,6,0,Math.PI,false); ctx.fill();
  ctx.fillStyle='#2b2f36'; ctx.beginPath(); ctx.arc(-3,-17,1.4,0,Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(3,-17,1.4,0,Math.PI*2); ctx.fill();
  // Helm/Haube
  ctx.fillStyle='#1e2a44'; ctx.beginPath(); ctx.arc(0,-19,10,Math.PI,0); ctx.fill();
  // Lichtschwert – rotiert permanent um Spieler
  ctx.rotate(swordAngle);
  const bladeLen = 38 + bonuses.range*22;
  // Glow
  ctx.shadowColor='#ff2d2d'; ctx.shadowBlur=14; ctx.fillStyle='#ff2d2d'; ctx.beginPath(); ctx.roundRect(player.radius-1, -3, bladeLen, 6, 3); ctx.fill();
  ctx.shadowBlur=6; ctx.fillStyle='#ff8a8a'; ctx.beginPath(); ctx.roundRect(player.radius, -1, bladeLen-6, 2, 1); ctx.fill();
  ctx.shadowBlur=0;
  // Griff
  ctx.fillStyle='#9aa5bf'; ctx.beginPath(); ctx.roundRect(7,-4,16,8,2); ctx.fill();
  ctx.fillStyle='#6b7a94'; ctx.beginPath(); ctx.rect(11,-4,3,8); ctx.fill(); ctx.beginPath(); ctx.rect(16,-4,2,8); ctx.fill();
  ctx.fillStyle='#ffcc33'; ctx.beginPath(); ctx.arc(7,-0,2,0,Math.PI*2); ctx.fill();
  ctx.restore();
  // particles
  for(const p of particles){
    if(p.sword){
      ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.angle);
      ctx.globalAlpha=Math.max(0,p.life/p.max);
      ctx.fillStyle='rgba(255,236,139,.9)'; ctx.fillRect(0,-3, p.size,6);
      ctx.restore(); continue;
    }
    ctx.globalAlpha=Math.max(0,p.life/p.max);
    ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha=1;
  // floats
  ctx.font='700 13px system-ui'; ctx.textAlign='center';
  for(const f of floats){ ctx.globalAlpha=Math.max(0,f.life/0.9); ctx.fillStyle=f.color; ctx.fillText(f.text,f.x,f.y); }
  ctx.globalAlpha=1;
  ctx.restore();
}

function loop(t){
  raf=requestAnimationFrame(loop);
  if(!lastTime) lastTime=t;
  const dt=Math.min(50, t-lastTime); lastTime=t;
  if(state==='playing') update(dt);
  draw();
}
loop(performance.now());

// prevent context menu / selection
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('selectstart',e=>e.preventDefault());
