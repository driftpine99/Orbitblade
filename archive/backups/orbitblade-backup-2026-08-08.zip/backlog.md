# Orbitblade — Ideenspeicher

Stand: 8. August 2026. Spiel heißt jetzt **Orbitblade** (markenrechtlich unbedenklich umbenannt).
Ausrichtung: Veröffentlichung möglich, **Einmalkauf** (kein Free-to-Play). Fortschritt macht
das Spiel BREITER, nicht stärker. Vollversion-Schalter `FULL_VERSION` in game.js.
→ Beschlossene Neuerungen vom 8.8. (Abschnitt „Richtung / beschlossene Neuerungen" unten) führen
zusätzlich dauerhafte META-UPGRADES und Buff-Stufen ein — bewusster Kurswechsel Richtung
„auch stärker", deshalb überall Kappen + Preiseskalation.

---

## Heute erledigt (großer Progressions-Ausbau)

- **Umbenannt auf Orbitblade** — alle trademark-nahen Begriffe raus (Plasmaklinge, Schock,
  Drohne, Schüler/Ritter/Meister). Auch interne Schlüssel (Speicherstand-sicher).
- **Speichersystem** (`localStorage`, versioniert, migrationssicher) — Bestmarken je
  Schwierigkeit, Abzeichen, Freischaltungen, gewählter Skin, Mute-Zustand.
- **Etappen an Bosse gekoppelt** (alle 5 Wellen): Abzeichen + Freischaltung, endlos.
- **6 Klingenfarben** (2 Startfarben, Rest über Meilensteine); Skin-Auswahl im Fortschritts-Screen.
- **4 neue Fähigkeiten**, freischaltbar → landen im Level-Up-Pool: Kettenblitz, Konterstoß,
  Splitter, Dreifachklinge. Alle passiv (kein neuer Knopf).
- **9 Abzeichen** inkl. „Makellos" (Boss ohne Treffer) und „Meisterprüfung".
- **Fortschritts-/Sammlungs-Screen** (Startmenü → „Sammlung & Bestmarken").
- **Fairness/Feedback:** Boss-Schockwelle wird jetzt VORGEWARNT (Gefahrenband lädt sichtbar auf),
  Gegner-Treffer blitzen, Wellen-/Boss-/Meilenstein-Ansagen, Toast-Hinweise.
- **Sound** (prozedural, Web Audio, keine Dateien) mit Mute-Knopf, Zustand gespeichert.
- **Monetarisierung vorbereitet:** `FULL_VERSION=false` sperrt später `voll:true`-Inhalte
  (Splitter, Dreifachklinge, Türkis, Amethyst) trotz erreichtem Meilenstein → Gratis/Voll-Schnitt
  ist ein Datenfeld, kein Umbau.

## Richtung / beschlossene Neuerungen (8. August 2026)
Aus der Ideen-Durchsprache beschlossen. Rahmen für die Umsetzung: verzeihend für 7–70,
schwierigkeits-skaliert, keine externen Assets. Größere Umbauten: #8 (Fähigkeiten) und
#11 (Meta-Fortschritt) — jeweils als eigenes Feature mit Browser-Test am Ende.

### 1. Steuerung: Floating-Joystick
Basis springt zu der Stelle, wo der Finger aufsetzt (statt fester Kreis unten links).
Kurzer Hinweis beim ersten Start („Zum Laufen irgendwo auf den Bildschirm fassen").
Desktop unverändert (WASD/Pfeiltasten).

### 2. Gegner-Tempo & XP-Orbs
- Basis-Gegnertempo/-menge moderat anheben; Padawan bleibt verzeihend.
- Kill-XP bleibt automatisch. Zusätzlich **Bonus-XP-Orbs, nur zufällig**
  (jeder x-te Gegner). Vorschlag Feintuning: ~15 % Chance je Gegner, spätestens jeder
  8. Kill garantiert (Pity); Bosse/Stärkere droppen immer einen (oder größere);
  Orbs mit Magnetradius wie die Münzen.

### 3. Distanz- und Exploder-Gegner (erst ab späteren Wellen)
- Distanz-Angreifer: Projektil-System, klarer Lade-Glow als Vorwarnung (Sprache wie Boss-Welle).
- Exploder: Zünd-Puls vor dem Tod, Explosion mit Schadensabfall.
Beides klar erkennbar (Farbe/Form), schwierigkeits-skaliert (auf „Schüler" seltener/gar nicht).

### 4. Gegner-Design
Silhouetten-Prinzip (Form + Glow) beibehalten. Neue Typen mit eigenen Silhouetten
(z. B. Jäger-Drohne mit Flügeln, Alien) + subtile Animationen (pulsierender Kern,
Rotoren, „Atmen"). Inhaltlich an #3 gekoppelt: Distanz-/Exploder-Typen bekommen ihre Formen.

### 5. Hintergrund: Biome je Welle
Prozedurale Biome mit eigener Palette, Deko und Name (Orbitalring, Asteroidenfeld,
Nebelzone, Sternennebel …). Parallax + Landmarken, aber **Kampfebene lesbar und
kollisionsfrei** (reine Optik). Idee: alle 5 Wellen ein neues Biome (passend zu den Boss-Wellen).

### 6. Lebensregeneration
- Basis: langsames passives Regen, **schwächer auf höheren Schwierigkeiten**.
- Dazu passive Fähigkeit „Regen je Kill" (siehe #8).
Regen so bemessen, dass Weglaufen nicht wieder attraktiv wird.

### 7. Bosse: schwerer + Erklärung + Fähigkeiten
- **Erklärung vorab** beim Boss-Auftritt (Banner-Ansage, z. B. „meide den lila Ring") +
  Kurzübersicht im Codex.
- Fähigkeiten: am Anfang **1–2** (Minions rufen, Sprint-Ramme, Spiralschüsse),
  spätere Boss-Wellen mehr (kleine Zustandsmaschine). Alle mit bestehendem
  Gefahrenband-Muster vorwarnen. Schwierigkeits-Skalierung („Schüler" weniger).

### 8. Fähigkeiten-System (großer Umbau) — Plan
Modell: **bewusste Freischaltung statt Zufall.** Drei Ebenen:
- **Meta (dauerhaft):** Freischaltung über **Meilensteine** (wie bisher). Ein „Kauf im Shop"
  entfällt im Lauf → dauerhafte Käufe laufen später über den Meta-Shop (#11).
- Freischalt-Wellen für die NEUEN Fähigkeiten hängen an den Boss-Wellen (pro Boss-Welle ggf.
  2 Freischaltungen, `MILESTONES`-Struktur dann erweitern). Vorschlag: Phaser→W10, Bombe→W20,
  Machtblitz-Nova→W30, Lebensregen→W40 (beim Umsetzen feinjustieren).
- **Lauf (pro Runde):** Build entsteht **NUR über Level-Up-Karten** (kein Lauf-Shop mehr).
- **Buffs:** pro Lauf, **max 10 Stufen**, nur für getragene Fähigkeiten, über Level-Up-Karten.

Slots & Kategorien:
- **2 aktive Slots**, frei belegbar aus dem Pool — Start Wirbel + Schock, **Umrüsten im
  Pause-Menü/Codex**. Aktive: Wirbel, Schock, **Bombe** (legen, verzögert explodiert),
  **Machtblitz-Nova** (elektr. Ring, Schaden + ~0,5 s Stun).
- **Max 5 passive Slots**: Kettenblitz, Konterstoß, Splitter, **Phaser** (schießt automatisch),
  **Lebensregen je Kill** — genau 5 Kandidaten.
- **Waffen-Upgrades (kein Slot):** Doppelklinge, Dreifachklinge.
- **Stat-Karten (unbegrenzt, gecappt):** +% Schaden, +% Reichweite, +% Rotationstempo.
- **Gelöscht: nichts.**

Level-Up-Karten-Regeln:
- Fähigkeits-Karten erscheinen nur, wenn Meta-freigeschaltet UND nicht schon im Lauf getragen.
- Buff-Karten erscheinen für bereits getragene Fähigkeiten (Stufe +1, max 10; Pips-Anzeige #9).
- **Codex-Screen „Pause → Fähigkeiten"**: alle Fähigkeiten mit Name, Beschreibung, Stufe,
  Freischalt-Bedingung + Slot-Umbestückung der 2 aktiven Slots.

### 9. Buff-Anzeige (Pips)
Pip-Reihe direkt an der Fähigkeit (gefüllte = Stufe) + volle „Stufe X von 10" im Codex.
Nur für gestufte Fähigkeiten; Einmal-Freischaltungen (Doppelklinge, Splitter …) sind an/aus.

### 10. Charakter-Optik
Animierter Umhang (weht in Laufrichtung), Rim-Light an den Konturen, Idle-Bobbing,
Partikel-Trail beim Laufen, Klinge mit Griff-Details + Glow-Fluss. Alles Canvas-basiert.
Später evtl. Sprite-Sheet, aber nicht jetzt.

### 11. Shop-Umbau: Meta-Fortschritt (großer Umbau)
- **Der bisherige Shop zwischen den Wellen fällt weg** → es gibt nur noch den **Meta-Shop
  NACH dem Lauf**, der **nur langfristige Meta-Buffs anbietet, KEINE Items**.
  Heiltrank/Schild/Schadens-Boost gibt es im Shop nicht mehr; Heilung im Lauf über
  #6 Basis-Regen + #8 Lebensregen. Optional (Vorschlag): Heiltrank als seltener Orb-Drop.
- **Meta-Sterne** (persistente Währung): am Laufende werden **~20 % der EINGESAMMELTEN**
  Münzen zu Sternen (Rest verfällt → kein Spare-Konflikt mit dem Lauf-Shop).
  Optional stabiler Sockel: +1 Stern pro überstandener Welle.
- **Meta-Upgrades** mit eskalierenden Preisen (z. B. +1 % Schaden 50g → 100g → 200g …)
  + **harte Kappen** (`CONFIG.caps` vorhanden); Schwierigkeiten nicht entkoppeln.
- **Skins**: später für Coins und/oder Echtgeld; Echtgeld sauber getrennt von der
  `FULL_VERSION`-Gratis-Demo (Jugendschutz/EU-Recht).
- **Speicherstand-Migration** (`SAVE_VERSION`-Bump) für neue Währung + gekaufte Upgrades.

---

## WICHTIG: noch nicht visuell getestet
Die gesamte Optik (Boss-Vorwarnung, Splitter, Kettenblitz-Linien, Skins, Fortschritts-Screen,
Ansagen) ist NUR über die Node-Simulation geprüft (Logik grün), nicht im echten Browser gesehen.
**Erster Schritt morgen: im Browser öffnen und durchspielen**, besonders:
- Sehen die Boss-Vorwarnung und der Gefahrenring gut/fair aus?
- Wirken Kettenblitz, Splitter, Doppelklinge/Dreifachklinge sauber?
- Ist der Fortschritts-Screen auf dem Tablet gut bedienbar?
- Balance der neuen Fähigkeiten (Kettenblitz/Splitter evtl. zu stark?).

---

## Als Nächstes dran

### Manuell nutzbare Items im Shop
~~ENTFÄLLT (Beschluss 8.8.)~~ → siehe #11: Der Shop bietet nur noch langfristige Meta-Buffs,
KEINE Items mehr (Heiltrank/Schild/Bombe als Shop-Items gestrichen).

### Monetarisierung / Veröffentlichung
- Vor Release: Markenrecherche „Orbitblade" (Steam-, App-Store-Suche, DPMA, Domain).
- Weg wählen: itch.io (schnell, HTML5 direkt) → später Google Play / App Store (Capacitor).
- Kostenlose Web-Demo als Trichter, Vollversion über Plattform (Plattform übernimmt Zahlung + Jugendschutz).
- KEIN F2P, keine Werbung an Kinder, keine Lootboxen (EU/DE-Recht). Anwaltliche Prüfung vor Release.

### Weitere Inhalte für den Freischalt-Motor
- Zweiter Charakter „Wächter" (mehr Leben, langsamer) — Datenmodell dafür steht noch aus.
- Schwierigkeit „Großmeister" nach Sieg auf Meister.
- Mehr Abzeichen/Skins als langfristige Ziele.

---

## Optik und Gefühl (noch offen)
- Kamera weich nachziehen (bewusst NICHT gemacht: Spieler soll exakt zentriert bleiben; ggf. später mild).
- Boss-Auftritt noch spektakulärer inszenieren.

## Technik
- `game.js` ist jetzt ~1050 Zeilen — bei weiterem Wachstum in Module teilen.
- Artifact neu bauen: `scratchpad/build.js` fügt die 3 Dateien zu einer HTML zusammen.
  Node-Testsuite: `scratchpad/harness.js` (+ Testskripte). Link bleibt beim Neu-Veröffentlichen gleich.
- Offene Design-Frage bleibt: kleiner, hart gedeckelter Rang-Bonus zusätzlich? (Erst nach Freischaltungen.)
