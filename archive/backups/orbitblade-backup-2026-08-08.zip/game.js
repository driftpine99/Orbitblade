/* Orbitblade — CONFIG zentral anpassbar */
const CONFIG = {
  baseDamage: 25,          // Basiswert, auf dem der Wirbelangriff aufbaut
  wirbelCooldown: 8000,
  wirbelRadius: 140,
  wirbelDamageMult: 1.5,
  stossCooldown: 12000,
  stossRange: 200,
  stossPush: 120,
  stossDamage: 30,
  playerBaseSpeed: 175,
  playerRadius: 18,
  // Plasmaklinge: Rundumschaden als verzeihende Basis, die echte Klingenposition
  // ("Sweet Spot") gibt deutlich mehr. Dadurch zählen Rotation und Doppelklinge wirklich.
  swordSpinSpeed: 6.0,     // Rotationstempo (rad/s)
  bladeBaseLen: 38,        // Klingenlänge bei 0% Reichweiten-Bonus
  spinDamage: 12,          // Rundum-Grundschaden pro Treffer-Tick
  spinArcBonus: 26,        // Zusatzschaden, wenn die Klinge den Gegner wirklich trifft
  spinArcHalf: 0.5,        // halbe Trefferbreite der Klinge (rad) → ca. 57° gesamt
  spinHitInterval: 120,    // ms zwischen den Treffer-Ticks
  // Tempo bewusst nah am Spieler (175): Weglaufen soll Zeit kosten, nicht alles lösen
  enemyTypes: {
    drohne: { hp:28, dmg:8, speed:165, radius:14, color:'#8ec8ff', coin:5, xp:12 },
    soldat: { hp:60, dmg:12, speed:125, radius:18, color:'#ff8a3d', coin:10, xp:20 },
    schwer: { hp:125, dmg:20, speed:85, radius:24, color:'#c94a4a', coin:18, xp:30 },
    boss:   { hp:520, dmg:28, speed:105, radius:34, color:'#b84dff', coin:50, xp:80 }
  },
  wave: { baseCount:5, perWave:2.5, hpScale:0.08, dmgScale:0.08, spawnInterval: 700 },
  xpBase: 100, xpPerLevel: 55,
  shop: {
    healPrice:30, healAmount: 999,
    dmgBoostPrice:40, dmgBoostDur:30000,
    shieldPrice:40, shieldDur:10000,
    moveSpeedPrice:50, maxHpPrice:60
  },
  caps: { dmgMult:2.0, speedMult:1.6, rangeMult:1.8, fireRateMult:1.5, maxHpBonus:150 },
  // Freischaltbare Fähigkeiten (passiv, kein neuer Knopf)
  abil: {
    chainDamage:14, chainRange:140,          // Kettenblitz: springt zum nächsten Gegner
    counterDamage:22, counterRadius:110, counterCd:600, counterPush:90,  // Konterstoß bei Treffer
    splitterDamage:9, splitterCount:2, splitterRadius:70, splitterSpeed:3.2, splitterHitCd:250 // kreisende Splitter
  },
  bossWarn:1100,   // ms Vorwarnung, bevor die Boss-Schockwelle zuschlägt
  difficulty: {
    schueler:{ playerHp:200, enemySpeed:0.75, enemyCount:0.7, enemyDmg:0.7 },
    ritter:{ playerHp:150, enemySpeed:1.0, enemyCount:1.0, enemyDmg:1.0 },
    meister:{ playerHp:100, enemySpeed:1.2, enemyCount:1.4, enemyDmg:1.25 }
  }
};

/* ============================================================
   PROGRESSION — Skins, Meilensteine, Abzeichen, Speicherstand
   Bewusst: kein Server, keine personenbezogenen Daten (DSGVO/Jugendschutz simpel).
   Fortschritt macht das Spiel BREITER, nicht stärker.
   ============================================================ */

// Vollversion-Schalter. Für eine kostenlose Web-Demo später auf false setzen:
// Inhalte mit voll:true bleiben dann trotz erreichtem Meilenstein gesperrt ("Vollversion").
const FULL_VERSION = true;

// Klingenfarben. start:true = von Anfang an wählbar. voll:true = nur Vollversion.
const SKINS = {
  rubin:    { name:'Rubin',     blade:'#ff3b3b', core:'#ffffff', start:true },
  azur:     { name:'Azur',      blade:'#3b82ff', core:'#dbeaff', start:true },
  bernstein:{ name:'Bernstein', blade:'#ffb340', core:'#fff3d6' },
  smaragd:  { name:'Smaragd',   blade:'#3bd17a', core:'#e9fff1' },
  tuerkis:  { name:'Türkis',    blade:'#35e0e0', core:'#e0ffff', voll:true },
  amethyst: { name:'Amethyst',  blade:'#b45bff', core:'#f2e6ff', voll:true },
};

// Freischaltbare Fähigkeiten (Metadaten für Gating + Anzeige; Wirkung siehe Level-Up-Pool/Combat)
const ABILITIES = {
  kettenblitz:  { name:'Kettenblitz',   desc:'Treffer springt zum nächsten Gegner' },
  konterstoss:  { name:'Konterstoß',    desc:'Wirst du getroffen, schlägst du automatisch zurück' },
  splitter:     { name:'Splitter',      desc:'Kreisende Energiesplitter richten Zusatzschaden an', voll:true },
  dreifachklinge:{ name:'Dreifachklinge',desc:'Dritte Klinge — lückenlose Deckung', voll:true },
};

// Abzeichen (Sammlung). Bosse alle 5 Wellen sind die natürlichen Etappen.
const BADGES = {
  boss1:   { name:'Erster Boss',   desc:'Den ersten Boss bezwungen',        glyph:'V' },
  welle10: { name:'Standhaft',     desc:'Welle 10 überstanden',             glyph:'X' },
  welle15: { name:'Unaufhaltsam',  desc:'Welle 15 überstanden',             glyph:'XV' },
  welle20: { name:'Veteran',       desc:'Welle 20 überstanden',             glyph:'XX' },
  welle25: { name:'Legende',       desc:'Welle 25 überstanden',             glyph:'XXV' },
  welle30: { name:'Unsterblich',   desc:'Welle 30 überstanden',             glyph:'XXX' },
  doppel:  { name:'Zwei Klingen',  desc:'Die Doppelklinge in einem Lauf geholt', glyph:'≡' },
  makellos:{ name:'Makellos',      desc:'Einen Boss ohne einen Treffer besiegt',  glyph:'✦' },
  meister: { name:'Meisterprüfung',desc:'Welle 10 auf Schwierigkeit Meister',     glyph:'★' },
};

// Etappen: erreichte Welle -> Abzeichen + Freischaltung. An die Bosse gekoppelt.
const MILESTONES = [
  { wave:5,  badge:'boss1',   unlock:{ kind:'ability', id:'kettenblitz' } },
  { wave:10, badge:'welle10', unlock:{ kind:'skin',    id:'bernstein' } },
  { wave:15, badge:'welle15', unlock:{ kind:'ability', id:'konterstoss' } },
  { wave:20, badge:'welle20', unlock:{ kind:'skin',    id:'smaragd' } },
  { wave:25, badge:'welle25', unlock:{ kind:'ability', id:'splitter' } },
  { wave:30, badge:'welle30', unlock:{ kind:'skin',    id:'amethyst' } },
  { wave:35, badge:null,      unlock:{ kind:'ability', id:'dreifachklinge' } },
  { wave:40, badge:null,      unlock:{ kind:'skin',    id:'tuerkis' } },
];

const SAVE_KEY='orbitblade_save', SAVE_VERSION=1;
const DEFAULT_SAVE={ v:SAVE_VERSION, best:{schueler:0,ritter:0,meister:0}, badges:{}, unlocks:{}, skin:'rubin', muted:false, bossKills:0 };
let save = clone(DEFAULT_SAVE);

function clone(o){ return JSON.parse(JSON.stringify(o)); }
function loadSave(){
  try{
    const raw = (typeof localStorage!=='undefined') && localStorage.getItem(SAVE_KEY);
    if(raw){
      const data=JSON.parse(raw);
      save = migrateSave(data);
    }
  }catch(e){ save = clone(DEFAULT_SAVE); }
  // Fehlende Felder aus den Defaults auffüllen (macht spätere Updates unkritisch)
  save = Object.assign(clone(DEFAULT_SAVE), save);
  save.best = Object.assign({schueler:0,ritter:0,meister:0}, save.best||{});
  if(!SKINS[save.skin]) save.skin='rubin';
}
function migrateSave(data){
  // Platz für spätere Versionssprünge; aktuell nur v1
  if(!data || typeof data!=='object') return clone(DEFAULT_SAVE);
  data.v = SAVE_VERSION;
  return data;
}
function persist(){
  try{ if(typeof localStorage!=='undefined') localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }catch(e){}
}

// Ist ein Inhalt aktuell nutzbar? (Start-Inhalt, oder freigeschaltet und nicht Vollversions-gesperrt)
function isAvailable(kind, id){
  const meta = kind==='skin' ? SKINS[id] : ABILITIES[id];
  if(!meta) return false;
  if(meta.start) return true;
  if(!save.unlocks[kind+':'+id]) return false;
  if(meta.voll && !FULL_VERSION) return false;
  return true;
}
// Wurde ein Inhalt am Meilenstein erreicht (unabhängig von Vollversion)?
function isEarned(kind, id){ const m=kind==='skin'?SKINS[id]:ABILITIES[id]; return !!(m&&(m.start||save.unlocks[kind+':'+id])); }

function earnBadge(id){ if(id && !save.badges[id]){ save.badges[id]=true; persist(); pushToast('Abzeichen: '+BADGES[id].name); return true; } return false; }
function grantUnlock(u){
  if(!u) return;
  const key=u.kind+':'+u.id;
  if(save.unlocks[key]) return;
  save.unlocks[key]=true; persist();
  const meta = u.kind==='skin'?SKINS[u.id]:ABILITIES[u.id];
  const label = u.kind==='skin' ? 'Klingenfarbe '+meta.name : 'Fähigkeit '+meta.name;
  if(meta.voll && !FULL_VERSION) pushToast('In der Vollversion: '+label);
  else pushToast('Neu: '+label);
}

/* ---- Sound: prozedural über Web Audio, keine Asset-Dateien ---- */
let audioCtx=null;
function initAudio(){
  if(audioCtx) return;
  try{ const AC=window.AudioContext||window.webkitAudioContext; if(AC) audioCtx=new AC(); }catch(e){ audioCtx=null; }
}
function tone(freq,dur,type,vol,when,slideTo){
  if(!audioCtx) return;
  const t0=audioCtx.currentTime+(when||0);
  const o=audioCtx.createOscillator(), g=audioCtx.createGain();
  o.type=type||'square'; o.frequency.setValueAtTime(freq,t0);
  if(slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(1,slideTo),t0+dur);
  g.gain.setValueAtTime(0.0001,t0);
  g.gain.exponentialRampToValueAtTime(vol||0.14,t0+0.008);
  g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
  o.connect(g); g.connect(audioCtx.destination);
  o.start(t0); o.stop(t0+dur+0.03);
}
const SFX={
  kill:    ()=>tone(320,0.08,'square',0.06,0,180),
  hurt:    ()=>tone(150,0.16,'sawtooth',0.15,0,70),
  wirbel:  ()=>tone(300,0.20,'sawtooth',0.11,0,760),
  stoss:   ()=>tone(190,0.22,'sine',0.15,0,60),
  levelup: ()=>{tone(520,0.12,'triangle',0.13);tone(780,0.16,'triangle',0.11,0.10);},
  pick:    ()=>tone(680,0.10,'triangle',0.12),
  buy:     ()=>tone(900,0.08,'square',0.10),
  coin:    ()=>tone(1050,0.05,'square',0.04),
  boss:    ()=>{tone(120,0.45,'sawtooth',0.16,0,70);tone(60,0.5,'sine',0.12);},
  bossdie: ()=>{tone(420,0.28,'sawtooth',0.15,0,120);tone(210,0.4,'sine',0.13,0.12);},
  shock:   ()=>tone(90,0.30,'sawtooth',0.16,0,40),
  counter: ()=>tone(520,0.12,'square',0.10,0,940),
  unlock:  ()=>{tone(700,0.10,'triangle',0.12);tone(1050,0.14,'triangle',0.10,0.08);},
  wave:    ()=>tone(460,0.14,'triangle',0.10),
  gameover:()=>{tone(300,0.3,'sawtooth',0.15,0,120);tone(150,0.5,'sine',0.13,0.15,80);},
};
function sfx(name){ if(save.muted||!audioCtx) return; const f=SFX[name]; if(f){ try{ f(); }catch(e){} } }
function updateMuteBtn(){ const b=document.getElementById('mute-btn'); if(b) b.textContent=save.muted?'🔇':'🔊'; }
function toggleMute(){ save.muted=!save.muted; persist(); updateMuteBtn(); if(!save.muted){ initAudio(); if(audioCtx&&audioCtx.state==='suspended') audioCtx.resume(); } }
// Audio erst nach erster Nutzer-Aktion starten (Browser-Autoplay-Sperre)
function unlockAudioOnce(){ initAudio(); if(audioCtx&&audioCtx.state==='suspended') audioCtx.resume(); window.removeEventListener('pointerdown',unlockAudioOnce); window.removeEventListener('keydown',unlockAudioOnce); window.removeEventListener('touchstart',unlockAudioOnce); }
window.addEventListener('pointerdown',unlockAudioOnce); window.addEventListener('keydown',unlockAudioOnce); window.addEventListener('touchstart',unlockAudioOnce);

const canvas=document.getElementById('game'), ctx=canvas.getContext('2d');
const healthBar=document.getElementById('health-bar'), healthText=document.getElementById('health-text');
const xpBar=document.getElementById('xp-bar'), levelText=document.getElementById('level-text');
const coinText=document.getElementById('coin-text'), waveText=document.getElementById('wave-text');
const overlayStart=document.getElementById('overlay-start'), overlayPause=document.getElementById('overlay-pause');
const overlayShop=document.getElementById('overlay-shop'), overlayLevel=document.getElementById('overlay-levelup');
const overlayOver=document.getElementById('overlay-gameover');
const shopGrid=document.getElementById('shop-grid'), shopCoin=document.getElementById('shop-coin'), shopWave=document.getElementById('shop-wave');
const levelupGrid=document.getElementById('levelup-grid');
const btnWirbel=document.getElementById('btn-wirbel'), btnStoss=document.getElementById('btn-stoss');
const cdWirbel=document.getElementById('cd-wirbel'), cdStoss=document.getElementById('cd-stoss');
const joystickBase=document.getElementById('joystick-base'), joystickStick=document.getElementById('joystick-stick'), joystickZone=document.getElementById('joystick-zone');

loadSave();
let state='menu', difficulty='schueler', raf=0, lastTime=0;
let player, enemies=[], coins=[], particles=[], floats=[];
let swordAngle=0, spinHitTimer=0;
let wave=1, waveEnemiesToSpawn=0, waveSpawned=0, spawnTimer=0;
let shake=0, wirbelCd=0, stossCd=0;
let dmgBoostUntil=0, shieldUntil=0, pendingShield=false, pendingBoost=false;
let bonuses={ dmg:0, speed:0, range:0, fireRate:0, maxHp:0, blades:1, chain:false, counter:false, splitter:0 };
let camX=0, camY=0, stossWaveT=0, wirbelT=0, wirbelShownR=0;
let counterCd=0, counterFx=0, shards=[]; // Konterstoß-Cooldown/Effekt, kreisende Splitter
let toasts=[], banner=null;              // kleine Hinweise oben, große Ansage in der Mitte
let bossActive=false, bossHitClean=true; // für das Abzeichen "Makellos"
let flashUntil=0;                        // kurzes Aufblitzen bei Spieler-Treffer

// Kleine Info oben (Freischaltung/Abzeichen), stapelbar
function pushToast(text){ toasts.push({text, life:2.8, y:0}); if(sfx) sfx('unlock'); }
// Große, kurze Ansage in der Bildschirmmitte (Welle/Boss/Meilenstein)
function announce(title, sub, color){ banner={title, sub:sub||'', color:color||'#e6edf7', life:2.2, max:2.2}; }

// Klingenlänge: multiplikativ, damit "+15% Reichweite" auch wirklich +15% bedeutet
function bladeLength(){ return CONFIG.bladeBaseLen * (1 + bonuses.range); }
// Winkel aller aktiven Klingen (Doppelklinge = zweite Klinge gegenüber)
function bladeAngles(){
  const out=[swordAngle];
  for(let i=1;i<bonuses.blades;i++) out.push(swordAngle + Math.PI*2*i/bonuses.blades);
  return out;
}
// kleinster Abstand zweier Winkel (0..PI)
function angleDiff(a,b){ let d=Math.abs(a-b)%(Math.PI*2); return d>Math.PI ? Math.PI*2-d : d; }
const DIFF_LABEL={schueler:'Schüler', ritter:'Ritter', meister:'Meister'};
function diffLabel(){ return DIFF_LABEL[difficulty]||difficulty; }
function currentSkin(){ const s=SKINS[save.skin]; return isAvailable('skin',save.skin)? s : SKINS.rubin; }

function resize(){
  const dpr=window.devicePixelRatio||1;
  const w=window.innerWidth, h=window.innerHeight;
  canvas.width=w*dpr; canvas.height=h*dpr;
  canvas.style.width=w+'px'; canvas.style.height=h+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
window.addEventListener('resize',resize); resize();

function newPlayer(){
  const d=CONFIG.difficulty[difficulty];
  const w = canvas.clientWidth || window.innerWidth;
  const h = canvas.clientHeight || window.innerHeight;
  return { x: w/2, y: h/2, vx:0, vy:0, face:0, radius: CONFIG.playerRadius,
    hp:d.playerHp, maxHp:d.playerHp, level:1, xp:0, xpNeed:CONFIG.xpBase, coins:0, hits:0 };
}
player = newPlayer();
window.playerRef = player;
window.addEventListener('load',()=>{ player = newPlayer(); window.playerRef = player; if(state==='menu') updateHUD(); });
function resetGame(){
  player=newPlayer(); window.playerRef = player; enemies=[]; coins=[]; particles=[]; floats=[];
  wave=1; waveEnemiesToSpawn=0; waveSpawned=0; spawnTimer=0;
  wirbelCd=0; stossCd=0; dmgBoostUntil=0; shieldUntil=0; stossWaveT=0; wirbelT=0; spinHitTimer=0;
  pendingShield=false; pendingBoost=false;
  bonuses={dmg:0,speed:0,range:0,fireRate:0,maxHp:0,blades:1,chain:false,counter:false,splitter:0};
  takenUpgrades={}; counterCd=0; shards=[]; bossActive=false; bossHitClean=true; flashUntil=0;
  toasts=[]; banner=null;
  shake=0; state='playing'; hideAll(); updateHUD(); startWave();
  announce('Welle 1', diffLabel()+' · überlebe die Arena', '#7cc8ff');
}
function hideAll(){
  overlayStart.classList.add('hidden'); overlayPause.classList.add('hidden');
  overlayShop.classList.add('hidden'); overlayLevel.classList.add('hidden'); overlayOver.classList.add('hidden');
}
function startWave(){
  const d=CONFIG.difficulty[difficulty];
  const count=Math.floor((CONFIG.wave.baseCount + wave*CONFIG.wave.perWave)*d.enemyCount);
  waveEnemiesToSpawn = (wave%5===0)? 1 : count;
  waveSpawned=0; spawnTimer=0;
  waveText.textContent='Welle '+wave;
  if(wave%5===0) spawnBoss();                                  // Boss-Welle (mit eigener Ansage)
  else if(wave>1) announce('Welle '+wave, '', '#7cc8ff');      // Welle 1 wird beim Start angesagt
  recordBest();
}
function spawnBoss(){
  const e=makeEnemy('boss'); enemies.push(e); waveSpawned=1;
  bossActive=true; bossHitClean=true;
  announce('Boss!', 'Welle '+wave, '#c77dff');
  if(sfx) sfx('boss');
}
// Boss besiegt -> Etappe geschafft: Abzeichen, Freischaltung, Statistik
function onBossDefeated(){
  bossActive=false;
  save.bossKills=(save.bossKills||0)+1;
  if(bossHitClean) earnBadge('makellos');
  if(difficulty==='meister' && wave>=10) earnBadge('meister');
  const m=MILESTONES.find(x=>x.wave===wave);
  if(m){ if(m.badge) earnBadge(m.badge); if(m.unlock) grantUnlock(m.unlock); }
  persist();
}
function recordBest(){
  if(wave>(save.best[difficulty]||0)){ save.best[difficulty]=wave; persist(); }
}
function makeEnemy(type){
  const t=CONFIG.enemyTypes[type];
  const scale=1+ (wave-1)*CONFIG.wave.hpScale;
  const dScale=1+ (wave-1)*CONFIG.wave.dmgScale;
  const diff=CONFIG.difficulty[difficulty];
  const w=canvas.clientWidth||window.innerWidth,h=canvas.clientHeight||window.innerHeight;
  const spawnDist=Math.hypot(w,h)/2 + 60;
  const ang=Math.random()*Math.PI*2;
  const x=player.x+Math.cos(ang)*spawnDist, y=player.y+Math.sin(ang)*spawnDist;
  return { type, x,y, hp:Math.round(t.hp*scale), maxHp:Math.round(t.hp*scale), dmg:Math.round(t.dmg*dScale*diff.enemyDmg), speed:t.speed*diff.enemySpeed, radius:t.radius, color:t.color, hitCd:0, bossTimer:0 };
}
function randomEnemyType(){
  const r=Math.random();
  if(wave<3) return r<0.75? 'drohne':'soldat';   // frühe Wellen: nur leichte Gegner
  if(r<0.5) return 'drohne';
  if(r<0.8) return 'soldat';
  return 'schwer';
}

// Input
let moveVec={x:0,y:0}, joystickTouchId=null;
let keys={};

function setJoystick(vx,vy){
  moveVec.x=vx; moveVec.y=vy;
  if(vx||vy) player.face=Math.atan2(vy,vx);
  const max=32;
  joystickStick.style.transform=`translate(${vx*max}px,${vy*max}px)`;
}
function handleJoystickTouch(e){
  e.preventDefault();
  const rect=joystickBase.getBoundingClientRect();
  const cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
  for(const t of e.changedTouches){
    if(e.type==='touchstart'){
      if(joystickTouchId===null && t.clientX>rect.left-20 && t.clientX<rect.left+rect.width+20 && t.clientY>rect.top-20 && t.clientY<rect.top+rect.height+20){
        joystickTouchId=t.identifier;       }
    }
  }
  if(joystickTouchId!==null){
    let found=null;
    for(const t of e.touches) if(t.identifier===joystickTouchId) found=t;
    if(found){
      let dx=(found.clientX-cx)/ (rect.width/2), dy=(found.clientY-cy)/(rect.height/2);
      const len=Math.hypot(dx,dy);
      if(len>1){dx/=len;dy/=len}
      setJoystick(dx,dy);
    }
    if(e.type==='touchend' || e.type==='touchcancel'){
      for(const t of e.changedTouches) if(t.identifier===joystickTouchId){
        joystickTouchId=null; setJoystick(0,0);
      }
    }
  }
}
joystickZone.addEventListener('touchstart',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchmove',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchend',handleJoystickTouch,{passive:false});
joystickZone.addEventListener('touchcancel',handleJoystickTouch,{passive:false});
// mouse fallback for joystick
let mouseDown=false;
joystickBase.addEventListener('mousedown',e=>{mouseDown=true; handleMouse(e)});
window.addEventListener('mousemove',e=>{if(mouseDown) handleMouse(e)});
window.addEventListener('mouseup',()=>{if(mouseDown){mouseDown=false;setJoystick(0,0)}});
function handleMouse(e){
  const rect=joystickBase.getBoundingClientRect();
  const cx=rect.left+rect.width/2, cy=rect.top+rect.height/2;
  let dx=(e.clientX-cx)/(rect.width/2), dy=(e.clientY-cy)/(rect.height/2);
  const len=Math.hypot(dx,dy); if(len>1){dx/=len;dy/=len}
  setJoystick(dx,dy);
}
window.addEventListener('keydown',e=>{
  keys[e.key.toLowerCase()]=true;
  if(e.key==='1') doWirbel();
  if(e.key==='2') doStoss();
  if(e.key==='Escape' && state==='playing') pauseGame();
  if(e.key==='Escape' && state==='paused') resumeGame();
});
window.addEventListener('keyup',e=> keys[e.key.toLowerCase()]=false);
canvas.addEventListener('touchstart',e=>{
  // prevent scroll, but allow buttons: only prevent if not on button
  if(e.target.closest('button')) return;
  e.preventDefault();
},{passive:false});

// Pause
function pauseGame(){ if(state!=='playing') return; state='paused'; overlayPause.classList.remove('hidden'); }
function resumeGame(){ if(state!=='paused') return; state='playing'; overlayPause.classList.add('hidden'); lastTime=performance.now(); }
document.getElementById('pause-btn').addEventListener('click',pauseGame);
document.getElementById('resume-btn').addEventListener('click',resumeGame);
document.getElementById('restart-btn-pause').addEventListener('click',()=>{ resetGame(); });
document.getElementById('restart-btn').addEventListener('click',()=>{ overlayOver.classList.add('hidden'); document.getElementById('overlay-start').classList.remove('hidden'); state='menu'; });
document.getElementById('start-btn').addEventListener('click',resetGame);
document.querySelectorAll('.diff-btn').forEach(b=>{
  b.addEventListener('click',()=>{
    document.querySelectorAll('.diff-btn').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); difficulty=b.dataset.diff;
  });
});

// Fortschritts-Screen (Bestmarken, Skins, Abzeichen)
function skinReqWave(id){ const m=MILESTONES.find(x=>x.unlock&&x.unlock.kind==='skin'&&x.unlock.id===id); return m?m.wave:null; }
function renderProgress(){
  const bg=document.getElementById('best-grid'); bg.innerHTML='';
  for(const k of ['schueler','ritter','meister']){
    const d=document.createElement('div'); d.className='best-cell';
    d.innerHTML=`<span class="best-name">${DIFF_LABEL[k]}</span><span class="best-val">Welle ${save.best[k]||0}</span>`;
    bg.appendChild(d);
  }
  const sg=document.getElementById('skin-grid'); sg.innerHTML='';
  for(const id in SKINS){
    const s=SKINS[id], avail=isAvailable('skin',id), earned=isEarned('skin',id);
    const cell=document.createElement('button');
    cell.className='skin-cell'+(save.skin===id?' active':'')+(avail?'':' locked');
    let lock='';
    if(!avail){ const rw=skinReqWave(id); lock = (earned && s.voll) ? 'Vollversion' : (rw?'ab Welle '+rw:'gesperrt'); }
    cell.innerHTML=`<span class="skin-dot" style="background:${s.blade}"></span><span class="skin-name">${s.name}</span>`+
      (avail?'':`<span class="lock">🔒 ${lock}</span>`);
    if(avail) cell.onclick=()=>{ save.skin=id; persist(); if(sfx) sfx('pick'); renderProgress(); };
    sg.appendChild(cell);
  }
  const bag=document.getElementById('badge-grid'); bag.innerHTML='';
  for(const id in BADGES){
    const b=BADGES[id], have=!!save.badges[id];
    const cell=document.createElement('div'); cell.className='badge-cell'+(have?' have':'');
    cell.innerHTML=`<span class="badge-medal">${have?b.glyph:'·'}</span><span class="badge-name">${b.name}</span>`+
      `<span class="badge-desc">${have?b.desc:'Noch nicht erreicht'}</span>`;
    bag.appendChild(cell);
  }
}
function openProgress(){ renderProgress(); overlayStart.classList.add('hidden'); document.getElementById('overlay-progress').classList.remove('hidden'); }
function closeProgress(){ document.getElementById('overlay-progress').classList.add('hidden'); overlayStart.classList.remove('hidden'); }
document.getElementById('progress-btn').addEventListener('click',openProgress);
document.getElementById('progress-back').addEventListener('click',closeProgress);
document.getElementById('mute-btn').addEventListener('click',toggleMute);
updateMuteBtn();

// Specials
function doWirbel(){
  if(state!=='playing' || wirbelCd>0) return;
  wirbelCd=CONFIG.wirbelCooldown;
  const dmg=Math.round(CONFIG.baseDamage*(1+bonuses.dmg)*CONFIG.wirbelDamageMult * (dmgBoostUntil>Date.now()?2:1));
  const r=CONFIG.wirbelRadius*(1+bonuses.range*0.5);
  for(const en of enemies){
    if(Math.hypot(en.x-player.x,en.y-player.y) < r + en.radius){
      en.hp-=dmg; spawnParticles(en.x,en.y,en.color,8); pushFloat(en.x,en.y-20,'-'+dmg,'#ffcc33');
    }
  }
  spawnParticles(player.x,player.y,'#ffcc33',14);
  wirbelT=1; wirbelShownR=r;   // Optik nutzt exakt den Trefferradius
  shake=8; if(sfx) sfx('wirbel');
}
function doStoss(){
  if(state!=='playing' || stossCd>0) return;
  stossCd=CONFIG.stossCooldown;
  const dmg=Math.round(CONFIG.stossDamage*(1+bonuses.dmg)*(dmgBoostUntil>Date.now()?2:1));
  const range=CONFIG.stossRange;
  // 360°-Schubwelle: stößt alle Gegner im Umkreis radial nach außen
  for(const en of enemies){
    const dx=en.x-player.x, dy=en.y-player.y;
    const d=Math.hypot(dx,dy);
    if(d < range+en.radius){
      en.hp-=dmg;
      const a = d>0.001 ? Math.atan2(dy,dx) : Math.random()*Math.PI*2;
      en.x += Math.cos(a)*CONFIG.stossPush;
      en.y += Math.sin(a)*CONFIG.stossPush;
      spawnParticles(en.x,en.y,'#6ec8ff',6);
      pushFloat(en.x,en.y-18,'-'+dmg,'#6ec8ff');
    }
  }
  spawnParticles(player.x,player.y,'#6ec8ff',18);
  stossWaveT=1;   // expandierender Ring-Effekt
  shake=7; if(sfx) sfx('stoss');
}
// Zentraler Spieler-Schaden: Effekte, Konterstoß, Tod an einer Stelle
function hurtPlayer(dmg){
  if(Date.now()<=shieldUntil) return false;      // Schild absorbiert
  player.hp-=dmg; shake=Math.max(shake,6); flashUntil=Date.now()+140;
  spawnParticles(player.x,player.y,'#ff4d4d',6);
  if(bossActive) bossHitClean=false;             // "Makellos" verwirkt
  if(sfx) sfx('hurt');
  if(bonuses.counter && counterCd<=0) doCounter();
  if(player.hp<=0){ player.hp=0; updateHUD(); gameOver(); return true; }
  return false;
}
// Konterstoß: automatische Mini-Schockwelle, wenn man getroffen wird
function doCounter(){
  counterCd=CONFIG.abil.counterCd; counterFx=1;
  const R=CONFIG.abil.counterRadius, dmg=CONFIG.abil.counterDamage;
  for(const en of enemies){
    const dx=en.x-player.x, dy=en.y-player.y, d=Math.hypot(dx,dy);
    if(d<R+en.radius){
      en.hp-=dmg;
      const a=d>0.001?Math.atan2(dy,dx):Math.random()*Math.PI*2;
      en.x+=Math.cos(a)*CONFIG.abil.counterPush; en.y+=Math.sin(a)*CONFIG.abil.counterPush;
    }
  }
  spawnParticles(player.x,player.y,'#ff9a6b',12); if(sfx) sfx('counter');
}
// Kettenblitz zwischen zwei Punkten (nur Optik)
function addBolt(x1,y1,x2,y2){ particles.push({bolt:true, x:x1,y:y1, x2, y2, life:0.16, max:0.16}); }
btnWirbel.addEventListener('touchstart',e=>{e.preventDefault();doWirbel()});
btnStoss.addEventListener('touchstart',e=>{e.preventDefault();doStoss()});
btnWirbel.addEventListener('click',doWirbel);
btnStoss.addEventListener('click',doStoss);

// Coins, particles, floats
function dropCoin(x,y, amount){ coins.push({x,y,amount, r:8, taken:false}); }
function spawnParticles(x,y,color,n=6){
  for(let i=0;i<n;i++) particles.push({x,y, vx:(Math.random()-0.5)*240, vy:(Math.random()-0.5)*240, life:0.4+Math.random()*0.3, max:0.6, color, size:2+Math.random()*3});
}
function pushFloat(x,y,text,color){ floats.push({x,y,text,color,life:0.9, vy:-40}); }

/* Icons — schlichte Linien-Symbole, passend zum futuristischen Stil */
const ICON={
  schaden:'<path d="M4 20 16 8" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M14.5 6.5 19 4l-2.5 4.5z" fill="currentColor"/><circle cx="5" cy="19" r="2" fill="currentColor"/>',
  reichweite:'<circle cx="12" cy="12" r="3" fill="currentColor"/><circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-dasharray="3 3"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  tempo:'<path d="M13 2 5 13h6l-2 9 8-11h-6z" fill="currentColor"/>',
  doppel:'<path d="M6 21 11 9" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><path d="M18 21 13 9" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="6" r="2.6" fill="currentColor"/>',
  leben:'<path d="M12 20s-7-4.6-7-9.4A4 4 0 0 1 12 8a4 4 0 0 1 7-.6c0 4.8-7 12.6-7 12.6z" fill="currentColor"/>',
  laufen:'<circle cx="14" cy="4.5" r="2.2" fill="currentColor"/><path d="M9 21l3-5-2.5-3 1-4 4 3 3 1" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>',
  schild:'<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M9 12l2 2 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
  boost:'<path d="M12 3c3 4 5 6 5 9a5 5 0 0 1-10 0c0-3 2-5 5-9z" fill="currentColor"/>',
  kette:'<path d="M4 13l4-4M16 15l4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M13 4l-4 8h4l-2 8 6-10h-4z" fill="currentColor"/>',
  konter:'<circle cx="12" cy="12" r="3.4" fill="currentColor"/><path d="M12 4.5a7.5 7.5 0 0 1 0 15M12 4.5a7.5 7.5 0 0 0 0 15" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
  splitter:'<circle cx="12" cy="12" r="2.4" fill="currentColor"/><circle cx="12" cy="4" r="1.8" fill="currentColor"/><circle cx="20" cy="12" r="1.8" fill="currentColor"/><circle cx="12" cy="20" r="1.8" fill="currentColor"/><circle cx="4" cy="12" r="1.8" fill="currentColor"/><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1" stroke-dasharray="2 3" opacity=".6"/>',
  dreifach:'<path d="M12 21V9M5 20l5-11M19 20l-5-11" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="6" r="2.4" fill="currentColor"/>'
};
function svg(paths){ return `<svg class="card-icon" viewBox="0 0 24 24" aria-hidden="true">${paths}</svg>`; }

/* Level-Up = permanente Kampf-Identität (offensiv, baut den Charakter).
   Wiederholbare Stat-Karten + seltene, einmalige Freischaltungen. */
let takenUpgrades={};
const UPGRADE_POOL=[
  {id:'dmg', name:'+15% Schaden', desc:'Jeder Treffer sitzt härter', icon:ICON.schaden, color:'card-damage',
   available:()=>bonuses.dmg < CONFIG.caps.dmgMult-1-1e-9,
   cap:()=>`Grenze +${Math.round((CONFIG.caps.dmgMult-1)*100)}%`,
   apply:()=>{bonuses.dmg=Math.min(bonuses.dmg+0.15, CONFIG.caps.dmgMult-1)}},

  {id:'range', name:'+15% Reichweite', desc:'Die Klinge wird sichtbar länger', icon:ICON.reichweite, color:'card-range',
   available:()=>bonuses.range < CONFIG.caps.rangeMult-1-1e-9,
   cap:()=>`Grenze +${Math.round((CONFIG.caps.rangeMult-1)*100)}%`,
   apply:()=>{bonuses.range=Math.min(bonuses.range+0.15, CONFIG.caps.rangeMult-1)}},

  {id:'firerate', name:'+12% Rotationstempo', desc:'Das Schwert kreist schneller — mehr Treffer', icon:ICON.tempo, color:'card-firerate',
   available:()=>bonuses.fireRate < CONFIG.caps.fireRateMult-1-1e-9,
   cap:()=>`Grenze +${Math.round((CONFIG.caps.fireRateMult-1)*100)}%`,
   apply:()=>{bonuses.fireRate=Math.min(bonuses.fireRate+0.12, CONFIG.caps.fireRateMult-1)}},

  // Einmalige Freischaltung: taucht nach der Wahl nie wieder auf
  {id:'doppelklinge', name:'Doppelklinge', desc:'Zweite Klinge gegenüber — doppelte Deckung, kein blinder Winkel', icon:ICON.doppel, color:'card-unlock',
   once:true,
   available:()=>!takenUpgrades.doppelklinge && player.level>=3,
   cap:()=>'Einmalige Freischaltung',
   apply:()=>{bonuses.blades=2; earnBadge('doppel');}},

  // Freigeschaltete Fähigkeiten (erst nach Meilenstein im Pool, dann pro Lauf einmal wählbar)
  {id:'kettenblitz', name:'Kettenblitz', desc:'Voller Treffer springt zum nächsten Gegner über', icon:ICON.kette, color:'card-ability',
   once:true, available:()=>isAvailable('ability','kettenblitz') && !takenUpgrades.kettenblitz,
   cap:()=>'Freigeschaltete Fähigkeit', apply:()=>{bonuses.chain=true;}},

  {id:'konterstoss', name:'Konterstoß', desc:'Wirst du getroffen, schlägst du automatisch zurück', icon:ICON.konter, color:'card-ability',
   once:true, available:()=>isAvailable('ability','konterstoss') && !takenUpgrades.konterstoss,
   cap:()=>'Freigeschaltete Fähigkeit', apply:()=>{bonuses.counter=true;}},

  {id:'splitter', name:'Splitter', desc:'Zwei kreisende Energiesplitter treffen zusätzlich', icon:ICON.splitter, color:'card-ability',
   once:true, available:()=>isAvailable('ability','splitter') && bonuses.splitter===0,
   cap:()=>'Freigeschaltete Fähigkeit', apply:()=>{bonuses.splitter=CONFIG.abil.splitterCount;}},

  {id:'dreifachklinge', name:'Dreifachklinge', desc:'Dritte Klinge — lückenlose Deckung', icon:ICON.dreifach, color:'card-unlock',
   once:true, available:()=>isAvailable('ability','dreifachklinge') && bonuses.blades===2 && !takenUpgrades.dreifachklinge,
   cap:()=>'Setzt Doppelklinge voraus', apply:()=>{bonuses.blades=3;}},
];
// Wählt bis zu n unterschiedliche, aktuell verfügbare Karten
function pickUpgrades(n){
  const pool=UPGRADE_POOL.filter(u=>u.available());
  for(let i=pool.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [pool[i],pool[j]]=[pool[j],pool[i]]; }
  return pool.slice(0,n);
}
function checkLevelUp(){
  while(player.xp >= player.xpNeed){
    player.xp-=player.xpNeed; player.level++; player.xpNeed=Math.round(CONFIG.xpBase + player.level*CONFIG.xpPerLevel);
    triggerLevelUp();
  }
}
function triggerLevelUp(){
  const picks=pickUpgrades(3);
  // Alles ausgereizt? Dann keinen leeren Bildschirm zeigen, sondern weiterspielen.
  if(picks.length===0) return;
  state='levelup'; if(sfx) sfx('levelup');
  levelupGrid.innerHTML='';
  for(const up of picks){
    const btn=document.createElement('button');
    btn.className='levelup-card '+up.color;
    btn.innerHTML=`${svg(up.icon)}<h3>${up.name}</h3><p>${up.desc}</p><div class="cap">${up.cap()}</div>`;
    btn.onclick=()=>{
      up.apply();
      if(up.once) takenUpgrades[up.id]=true;
      if(sfx) sfx('pick');
      overlayLevel.classList.add('hidden'); state='playing'; lastTime=performance.now(); updateHUD();
    };
    levelupGrid.appendChild(btn);
  }
  overlayLevel.classList.remove('hidden');
}

// Shop
function openShop(){
  state='shop'; if(sfx) sfx('wave');
  shopWave.textContent=wave;
  shopCoin.textContent='Münzen: '+player.coins;
  renderShop();
  overlayShop.classList.remove('hidden');
}
/* Shop = Überleben und Taktik (defensiv, Mobilität, Verbrauchbares).
   Bewusst ohne Überschneidung mit den Level-Up-Karten. */
function renderShop(){
  const S=CONFIG.shop;
  const items=[
    {name:'Heiltrank', desc:'Leben sofort vollständig auffüllen', icon:ICON.leben, price:S.healPrice,
     can: player.coins>=S.healPrice && player.hp<player.maxHp,
     buy:()=>{ player.hp=player.maxHp; }},

    {name:'Schild', desc:'10 Sekunden unverwundbar — startet mit der nächsten Welle', icon:ICON.schild, price:S.shieldPrice,
     can: player.coins>=S.shieldPrice && !pendingShield,
     buy:()=>{ pendingShield=true; }},

    {name:'Schadens-Boost', desc:'30 Sekunden doppelter Schaden — startet mit der nächsten Welle', icon:ICON.boost, price:S.dmgBoostPrice,
     can: player.coins>=S.dmgBoostPrice && !pendingBoost,
     buy:()=>{ pendingBoost=true; }},

    {name:'Max-Leben +25', desc:'Dauerhaft mehr Puffer', icon:ICON.leben, price:S.maxHpPrice,
     can: player.coins>=S.maxHpPrice && bonuses.maxHp < CONFIG.caps.maxHpBonus,
     buy:()=>{ bonuses.maxHp+=25; player.maxHp+=25; player.hp+=25; }},

    {name:'Lauftempo +10%', desc:'Dauerhaft besser ausweichen', icon:ICON.laufen, price:S.moveSpeedPrice,
     can: player.coins>=S.moveSpeedPrice && bonuses.speed < CONFIG.caps.speedMult-1-1e-9,
     buy:()=>{ bonuses.speed=Math.min(bonuses.speed+0.10, CONFIG.caps.speedMult-1); }},
  ];
  shopGrid.innerHTML='';
  for(const it of items){
    const c=document.createElement('div'); c.className='shop-card';
    const gekauft=(it.name==='Schild'&&pendingShield)||(it.name==='Schadens-Boost'&&pendingBoost);
    c.innerHTML=`<div class="shop-head">${svg(it.icon)}<h3>${it.name}</h3></div><p>${it.desc}</p>`+
      `<button ${it.can?'':'disabled'}>${gekauft?'Bereit für die Welle':it.price+' Münzen'}</button>`;
    c.querySelector('button').onclick=()=>{
      if(!it.can) return;
      player.coins-=it.price; it.buy(); if(sfx) sfx('buy'); updateHUD(); renderShop();
    };
    shopGrid.appendChild(c);
  }
  shopCoin.textContent='Münzen: '+player.coins;
}
document.getElementById('shop-continue').addEventListener('click',()=>{
  overlayShop.classList.add('hidden');
  // Gekaufte Buffs starten erst jetzt — im Shop-Menü würden sie ungenutzt ablaufen
  if(pendingShield){ shieldUntil=Date.now()+CONFIG.shop.shieldDur; pendingShield=false; }
  if(pendingBoost){ dmgBoostUntil=Date.now()+CONFIG.shop.dmgBoostDur; pendingBoost=false; }
  wave++; startWave(); state='playing'; lastTime=performance.now();
});

// Auto attack
// Cooldown-Kreis + kurzer Puls im Moment der Bereitschaft
const wasReady={};
function updateCooldownUI(btn, sweep, cd, max, key){
  const rest=Math.max(0, Math.min(1, cd/max));
  sweep.style.setProperty('--cd', (rest*100).toFixed(1));
  const ready = cd<=0;
  btn.classList.toggle('on-cooldown', !ready);
  if(ready && wasReady[key]===false){
    btn.classList.remove('just-ready');
    void btn.offsetWidth;          // Animation neu starten
    btn.classList.add('just-ready');
  }
  wasReady[key]=ready;
}

// Update HUD
function updateHUD(){
  const pct=Math.max(0, player.hp/player.maxHp*100);
  healthBar.style.width=pct+'%';
  healthText.textContent=Math.ceil(player.hp)+' / '+player.maxHp;
  xpBar.style.width=(player.xp/player.xpNeed*100)+'%';
  levelText.textContent='Level '+player.level+' · XP '+player.xp+'/'+player.xpNeed;
  coinText.textContent='💰 '+player.coins;
}

// Game over
function gameOver(){
  state='gameover'; if(sfx) sfx('gameover');
  recordBest();
  const best=save.best[difficulty]||0;
  document.getElementById('gameover-stats').innerHTML=
    `Erreicht: <b>Welle ${wave}</b> · Level ${player.level} · ${player.coins} Münzen<br>`+
    `<span style="color:var(--muted)">Bestmarke ${diffLabel()}: Welle ${best}</span>`;
  overlayOver.classList.remove('hidden');
}

// Loop
function update(dt){
  if(state!=='playing') return;
  // cooldowns
  wirbelCd-=dt; stossCd-=dt;
  // Cooldown-Anzeige: verbleibender Anteil verdunkelt den Kreis
  updateCooldownUI(btnWirbel, cdWirbel, wirbelCd, CONFIG.wirbelCooldown, 'wirbel');
  updateCooldownUI(btnStoss,  cdStoss,  stossCd,  CONFIG.stossCooldown,  'stoss');

  // Bewegung – Spieler läuft frei durch die Welt, Kamera hält ihn zentriert
  const w=canvas.clientWidth || window.innerWidth, h=canvas.clientHeight || window.innerHeight;
  let ix=moveVec.x, iy=moveVec.y;
  if(keys['w']||keys['arrowup'])    iy-=1;
  if(keys['s']||keys['arrowdown'])  iy+=1;
  if(keys['a']||keys['arrowleft'])  ix-=1;
  if(keys['d']||keys['arrowright']) ix+=1;
  const mlen=Math.hypot(ix,iy);
  if(mlen>1){ ix/=mlen; iy/=mlen; }          // Diagonale nicht schneller; Joystick bleibt analog
  const pspeed=CONFIG.playerBaseSpeed*(1+bonuses.speed);
  player.x += ix*pspeed*dt/1000;
  player.y += iy*pspeed*dt/1000;
  // Plasmaklinge rotiert permanent um den Spieler
  swordAngle += CONFIG.swordSpinSpeed * (1 + bonuses.fireRate*0.6) * dt/1000;
  if(swordAngle>Math.PI*2) swordAngle-=Math.PI*2;
  player.face = swordAngle;
  // Effekt-Timer
  if(stossWaveT>0){ stossWaveT -= dt/380; if(stossWaveT<0) stossWaveT=0; }
  if(wirbelT>0){ wirbelT -= dt/420; if(wirbelT<0) wirbelT=0; }
  // Schwert-Treffer: Rundum-Grundschaden + Bonus dort, wo die Klinge wirklich ist
  spinHitTimer -= dt;
  if(spinHitTimer<=0){
    spinHitTimer = CONFIG.spinHitInterval;
    const bladeLen = bladeLength();
    const boost = dmgBoostUntil>Date.now()?2:1;
    const dmgBase = Math.round(CONFIG.spinDamage * (1+bonuses.dmg) * boost);
    const dmgArc  = Math.round((CONFIG.spinDamage+CONFIG.spinArcBonus) * (1+bonuses.dmg) * boost);
    for(const en of enemies){
      const dx=en.x-player.x, dy=en.y-player.y;
      const d = Math.hypot(dx,dy);
      if(d >= bladeLen + en.radius) continue;
      // Trifft eine der Klingen den Gegner gerade wirklich?
      const toEnemy = Math.atan2(dy,dx);
      const treffer = bladeAngles().some(a=>angleDiff(a,toEnemy) < CONFIG.spinArcHalf);
      const dmg = treffer ? dmgArc : dmgBase;
      en.hp -= dmg;
      spawnParticles(en.x,en.y, treffer?'#fff3b0':'#ffec8b', treffer?7:3);
      pushFloat(en.x,en.y-16,'-'+dmg, treffer?'#ffffff':'#ffec8b');
      // Kettenblitz: der volle Klingentreffer springt auf den nächsten Gegner über
      if(treffer && bonuses.chain){
        let best=null, bd=CONFIG.abil.chainRange;
        for(const o of enemies){ if(o===en) continue; const cd=Math.hypot(o.x-en.x,o.y-en.y); if(cd<bd){ bd=cd; best=o; } }
        if(best){ best.hp-=CONFIG.abil.chainDamage; addBolt(en.x,en.y,best.x,best.y); pushFloat(best.x,best.y-14,'-'+CONFIG.abil.chainDamage,'#9ad0ff'); }
      }
      if(en.hp<=0) continue;
      const ang = Math.atan2(dy,dx);
      en.x += Math.cos(ang)*(treffer?14:6);
      en.y += Math.sin(ang)*(treffer?14:6);
    }
  }
  // Splitter (kreisende Energie) aktualisieren
  if(bonuses.splitter>0){
    if(shards.length!==bonuses.splitter){ shards=[]; for(let i=0;i<bonuses.splitter;i++) shards.push({ang:i/bonuses.splitter*Math.PI*2, cd:0, x:player.x, y:player.y}); }
    const SR=CONFIG.abil.splitterRadius*(1+bonuses.range*0.4);
    for(const s of shards){
      s.ang += CONFIG.abil.splitterSpeed*dt/1000; s.cd-=dt;
      s.x=player.x+Math.cos(s.ang)*SR; s.y=player.y+Math.sin(s.ang)*SR;
      if(s.cd<=0){
        for(const en of enemies){ if(Math.hypot(en.x-s.x,en.y-s.y)<en.radius+7){ en.hp-=CONFIG.abil.splitterDamage; spawnParticles(s.x,s.y,'#9ad0ff',2); s.cd=CONFIG.abil.splitterHitCd; break; } }
      }
    }
  } else if(shards.length){ shards.length=0; }

  // spawn
  if(wave%5!==0){
    spawnTimer+=dt;
    if(waveSpawned < waveEnemiesToSpawn && spawnTimer > CONFIG.wave.spawnInterval){
      spawnTimer=0; enemies.push(makeEnemy(randomEnemyType())); waveSpawned++;
    }
  }
  // Gegner drängen sich auseinander, statt exakt übereinander zu stapeln
  for(let i=0;i<enemies.length;i++){
    const a=enemies[i];
    for(let j=i+1;j<enemies.length;j++){
      const b=enemies[j];
      const ox=b.x-a.x, oy=b.y-a.y; let od=Math.hypot(ox,oy); const minD=a.radius+b.radius;
      if(od>=minD) continue;
      let nx,ny;
      if(od<0.001){ const ang=(i*2.399+j); nx=Math.cos(ang); ny=Math.sin(ang); od=0.001; } // exakt gestapelt: auseinanderfächern
      else { nx=ox/od; ny=oy/od; }
      const push=(minD-od)/2;
      a.x-=nx*push; a.y-=ny*push; b.x+=nx*push; b.y+=ny*push;
    }
  }
  // enemies update
  const recycleDist=Math.hypot(w,h)*0.95;   // weit außer Sicht = wird neu positioniert
  for(const en of enemies){
    let dx=player.x-en.x, dy=player.y-en.y; let d=Math.hypot(dx,dy);
    // Dauerhaftes Weglaufen soll die Welle nicht einfrieren: Nachzügler rücken nach
    if(d>recycleDist){
      const a=Math.random()*Math.PI*2, sd=Math.hypot(w,h)/2+40;
      en.x=player.x+Math.cos(a)*sd; en.y=player.y+Math.sin(a)*sd;
      dx=player.x-en.x; dy=player.y-en.y; d=Math.hypot(dx,dy);
    }
    if(d>1){ en.x+= dx/d * en.speed * dt/1000; en.y+= dy/d * en.speed * dt/1000; }
    // attack if close
    if(d < en.radius + player.radius + 4){
      if(en.hitCd<=0){
        if(hurtPlayer(en.dmg)) return;
        en.hitCd=700;
      }
    }
    if(en.hitCd>0) en.hitCd-=dt;
    // Boss-Schockwelle MIT Vorwarnung — der gefährliche Ring wird sichtbar aufgeladen
    if(en.type==='boss'){
      en.bossTimer=(en.bossTimer||0)+dt;
      const warnStart=3000-CONFIG.bossWarn;
      en.warnT = en.bossTimer>warnStart ? Math.min(1,(en.bossTimer-warnStart)/CONFIG.bossWarn) : 0;
      if(en.bossTimer>=3000){
        en.bossTimer=0; en.warnT=0; en.shockFx=1;
        const dist=Math.hypot(player.x-en.x, player.y-en.y);
        if(dist>70 && dist<190){ if(hurtPlayer(20)) return; }   // im Gefahrenring? -> Treffer
        spawnParticles(en.x,en.y,'#c77dff',16); shake=Math.max(shake,9);
        if(sfx) sfx('shock');
      }
      if(en.shockFx>0) en.shockFx-=dt/350;
    }
  }
  if(counterCd>0) counterCd-=dt;
  if(counterFx>0){ counterFx-=dt/300; if(counterFx<0) counterFx=0; }
  // remove dead
  for(let i=enemies.length-1;i>=0;i--){
    if(enemies[i].hp<=0){
      const en=enemies[i];
      dropCoin(en.x,en.y, CONFIG.enemyTypes[en.type].coin);
      player.xp+=CONFIG.enemyTypes[en.type].xp;
      spawnParticles(en.x,en.y,en.color,en.type==='boss'?24:10);
      if(en.type==='boss'){ onBossDefeated(); shake=Math.max(shake,10); }
      if(sfx) sfx(en.type==='boss'?'bossdie':'kill');
      enemies.splice(i,1);
    }
  }
  checkLevelUp();
  // coins pickup
  for(let i=coins.length-1;i>=0;i--){
    const c=coins[i];
    const d=Math.hypot(c.x-player.x,c.y-player.y);
    if(d<28){ player.coins+=c.amount; pushFloat(c.x,c.y-10,'+'+c.amount,'#ffcc33'); if(sfx) sfx('coin'); coins.splice(i,1); continue; }
    // magnet
    if(d<90){ c.x+=(player.x-c.x)*4*dt/1000; c.y+=(player.y-c.y)*4*dt/1000; }
  }
  // particles
  for(let i=particles.length-1;i>=0;i--){
    const p=particles[i]; p.life-=dt/1000; if(p.life<=0){particles.splice(i,1); continue;}
    if(!p.sword && !p.bolt){ p.x+=p.vx*dt/1000; p.y+=p.vy*dt/1000; p.vy+= 300*dt/1000; }
  }
  for(let i=floats.length-1;i>=0;i--){ const f=floats[i]; f.life-=dt/1000; f.y+=f.vy*dt/1000; if(f.life<=0) floats.splice(i,1); }
  // Ansage & Hinweise altern lassen
  if(banner){ banner.life-=dt/1000; if(banner.life<=0) banner=null; }
  for(let i=toasts.length-1;i>=0;i--){ toasts[i].life-=dt/1000; if(toasts[i].life<=0) toasts.splice(i,1); }

  // wave clear check
  if(waveSpawned>=waveEnemiesToSpawn && enemies.length===0){
    if(state==='playing') openShop();
  }
  if(shake>0) shake-= dt*0.04;
  updateHUD();
}

function hexPath(c,r){ c.beginPath(); for(let i=0;i<6;i++){ const a=Math.PI/3*i; const x=Math.cos(a)*r, y=Math.sin(a)*r; i?c.lineTo(x,y):c.moveTo(x,y);} c.closePath(); }
function draw(){
  const w=canvas.clientWidth||window.innerWidth,h=canvas.clientHeight||window.innerHeight;
  ctx.clearRect(0,0,w,h);
  camX = player.x - w/2; camY = player.y - h/2;   // Kamera zentriert den Spieler
  let sx=0,sy=0;
  if(shake>0){ sx=(Math.random()-0.5)*shake*2; sy=(Math.random()-0.5)*shake*2; }
  ctx.save(); ctx.translate(sx,sy);
  // — Hintergrund: tiefes All mit weichem Kern-Glow (schlicht, futuristisch) —
  ctx.fillStyle='#05070d'; ctx.fillRect(0,0,w,h);
  const glow = ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,Math.max(w,h)*0.7);
  glow.addColorStop(0,'rgba(28,58,104,0.32)'); glow.addColorStop(0.5,'rgba(14,26,48,0.12)'); glow.addColorStop(1,'rgba(5,7,13,0)');
  ctx.fillStyle=glow; ctx.fillRect(0,0,w,h);
  // feines, scrollendes Raster
  const grid=54;
  const ox=-(((camX%grid)+grid)%grid), oy=-(((camY%grid)+grid)%grid);
  ctx.lineWidth=1; ctx.strokeStyle='rgba(74,132,204,0.09)';
  ctx.beginPath();
  for(let x=ox;x<=w;x+=grid){ ctx.moveTo(x,0); ctx.lineTo(x,h); }
  for(let y=oy;y<=h;y+=grid){ ctx.moveTo(0,y); ctx.lineTo(w,y); }
  ctx.stroke();
  // Knotenmarker (Fadenkreuze)
  ctx.strokeStyle='rgba(96,166,236,0.16)';
  ctx.beginPath();
  for(let x=ox;x<=w;x+=grid){ for(let y=oy;y<=h;y+=grid){ ctx.moveTo(x-3,y); ctx.lineTo(x+3,y); ctx.moveTo(x,y-3); ctx.lineTo(x,y+3); } }
  ctx.stroke();
  // Vignette
  const vig = ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*0.45,w/2,h/2,Math.max(w,h)*0.9);
  vig.addColorStop(0,'rgba(0,0,0,0)'); vig.addColorStop(1,'rgba(0,0,0,0.5)');
  ctx.fillStyle=vig; ctx.fillRect(0,0,w,h);

  // — Welt-Ebene (Kamera folgt Spieler) —
  ctx.save(); ctx.translate(-camX,-camY);
  const bladeLen = bladeLength();
  // dezenter Reichweiten-Ring
  ctx.strokeStyle='rgba(120,180,255,0.05)'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.arc(player.x,player.y, bladeLen+player.radius, 0, Math.PI*2); ctx.stroke();
  // Wirbelangriff: gefüllte, rotierende Spirale — Fläche = exakt der Trefferradius
  if(wirbelT>0){
    const t=1-wirbelT;                    // 0 -> 1 im Verlauf
    const R=wirbelShownR*Math.min(1,0.55+t*0.45);
    ctx.save(); ctx.translate(player.x,player.y);
    ctx.globalCompositeOperation='lighter';
    // Grundfläche: zeigt unmissverständlich, wie weit der Angriff reicht
    const g=ctx.createRadialGradient(0,0,R*0.15,0,0,R);
    g.addColorStop(0,'rgba(255,214,120,'+(0.34*wirbelT).toFixed(3)+')');
    g.addColorStop(0.7,'rgba(255,150,50,'+(0.18*wirbelT).toFixed(3)+')');
    g.addColorStop(1,'rgba(255,110,30,0)');
    ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,R,0,Math.PI*2); ctx.fill();
    // vier mitgerissene Schwaden
    ctx.rotate(t*5.0);
    ctx.strokeStyle='rgba(255,205,110,'+(0.75*wirbelT).toFixed(3)+')';
    ctx.lineWidth=3; ctx.lineCap='round';
    for(let s=0;s<4;s++){
      ctx.beginPath();
      for(let k=0;k<=16;k++){
        const f=k/16, ang=s*Math.PI/2 + f*2.1, rad=R*(0.18+f*0.82);
        const x=Math.cos(ang)*rad, y=Math.sin(ang)*rad;
        k?ctx.lineTo(x,y):ctx.moveTo(x,y);
      }
      ctx.stroke();
    }
    // scharfe Außenkante
    ctx.globalCompositeOperation='source-over';
    ctx.strokeStyle='rgba(255,190,90,'+(0.55*wirbelT).toFixed(3)+')'; ctx.lineWidth=2;
    ctx.beginPath(); ctx.arc(0,0,R,0,Math.PI*2); ctx.stroke();
    ctx.restore();
  }
  // Schockwelle (dünner Ring nach außen — bewusst anders als der Wirbel)
  if(stossWaveT>0){
    const rr = CONFIG.stossRange*(1-stossWaveT) + 8;
    ctx.save(); ctx.globalAlpha=stossWaveT*0.85;
    ctx.strokeStyle='#7cc8ff'; ctx.lineWidth=4; ctx.shadowColor='#7cc8ff'; ctx.shadowBlur=18;
    ctx.beginPath(); ctx.arc(player.x,player.y,rr,0,Math.PI*2); ctx.stroke();
    ctx.restore();
  }
  // Boss-Schockwelle: Gefahrenring VORWARNEN (Aufladung) + Auslöse-Blitz
  for(const en of enemies){
    if(en.type!=='boss') continue;
    if(en.warnT>0){
      ctx.save(); ctx.translate(en.x,en.y); ctx.globalCompositeOperation='lighter';
      ctx.fillStyle='rgba(199,125,255,'+(0.08+0.14*en.warnT).toFixed(3)+')';
      ctx.beginPath(); ctx.arc(0,0,190,0,Math.PI*2); ctx.arc(0,0,70,0,Math.PI*2); ctx.fill('evenodd'); // Gefahrenband 70–190
      ctx.globalCompositeOperation='source-over';
      ctx.strokeStyle='rgba(210,150,255,'+(0.35+0.5*en.warnT).toFixed(3)+')'; ctx.lineWidth=2+3*en.warnT;
      ctx.beginPath(); ctx.arc(0,0,70+120*en.warnT,0,Math.PI*2); ctx.stroke();   // Countdown-Rand
      ctx.restore();
    }
    if(en.shockFx>0){
      ctx.save(); ctx.translate(en.x,en.y); ctx.globalCompositeOperation='lighter';
      ctx.strokeStyle='rgba(199,125,255,'+(0.7*en.shockFx).toFixed(3)+')'; ctx.lineWidth=10*en.shockFx+2;
      ctx.beginPath(); ctx.arc(0,0,130,0,Math.PI*2); ctx.stroke();
      ctx.restore();
    }
  }
  // Konterstoß-Ring
  if(counterFx>0){
    ctx.save(); ctx.globalAlpha=counterFx; ctx.globalCompositeOperation='lighter';
    ctx.strokeStyle='#ff9a6b'; ctx.lineWidth=3; ctx.shadowColor='#ff9a6b'; ctx.shadowBlur=12;
    ctx.beginPath(); ctx.arc(player.x,player.y, CONFIG.abil.counterRadius*(1-counterFx)+18, 0, Math.PI*2); ctx.stroke();
    ctx.restore();
  }
  // coins – schlichte Glow-Hexchips
  for(const c of coins){
    ctx.save(); ctx.translate(c.x,c.y);
    ctx.shadowColor='#ffcf4d'; ctx.shadowBlur=10; ctx.fillStyle='#ffd257';
    hexPath(ctx,6); ctx.fill();
    ctx.shadowBlur=0; ctx.fillStyle='rgba(255,255,255,0.55)';
    ctx.beginPath(); ctx.arc(-1.5,-1.8,1.5,0,Math.PI*2); ctx.fill();
    ctx.restore();
  }
  // enemies – futuristische Neon-Silhouetten
  for(const en of enemies){
    const r=en.radius;
    const ang = Math.atan2(player.y-en.y, player.x-en.x);
    // Bodenschatten (nicht rotiert)
    ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.beginPath(); ctx.ellipse(en.x, en.y+r*0.75, r*0.85, r*0.35,0,0,Math.PI*2); ctx.fill();
    ctx.save(); ctx.translate(en.x,en.y); ctx.rotate(ang);
    ctx.lineJoin='round'; ctx.shadowColor=en.color; ctx.shadowBlur=15; ctx.strokeStyle=en.color; ctx.lineWidth=2.5;
    if(en.type==='drohne'){
      // Drohne: schnelle Pfeil-/Rautenform, Sensorauge nach vorne
      ctx.fillStyle='#0a1526';
      ctx.beginPath(); ctx.moveTo(r,0); ctx.lineTo(-r*0.2,r*0.8); ctx.lineTo(-r*0.7,0); ctx.lineTo(-r*0.2,-r*0.8); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.shadowBlur=6; ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(r*0.28,0,r*0.2,0,Math.PI*2); ctx.fill();
    } else if(en.type==='soldat'){
      // Soldat: gepanzertes Quadrat mit leuchtendem Visier
      ctx.fillStyle='#1c1020';
      ctx.beginPath(); ctx.roundRect(-r*0.8,-r*0.8,r*1.6,r*1.6,6); ctx.fill(); ctx.stroke();
      ctx.shadowBlur=6; ctx.fillStyle=en.color; ctx.beginPath(); ctx.roundRect(r*0.02,-r*0.3,r*0.5,r*0.6,3); ctx.fill();
    } else if(en.type==='schwer'){
      // Schwer: massiver Hexpanzer mit Reaktorkern
      ctx.fillStyle='#1e0d0d';
      hexPath(ctx,r); ctx.fill(); ctx.stroke();
      ctx.shadowBlur=6; ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(0,0,r*0.34,0,Math.PI*2); ctx.fill();
    } else { // boss
      ctx.lineWidth=3; ctx.fillStyle='#160a24';
      hexPath(ctx,r); ctx.fill(); ctx.stroke();
      ctx.strokeStyle='rgba(200,120,255,0.45)'; ctx.lineWidth=6; ctx.shadowBlur=14;
      ctx.beginPath(); ctx.arc(0,0,r+9,0,Math.PI*2); ctx.stroke();
      ctx.shadowBlur=6; ctx.fillStyle=en.color; ctx.beginPath(); ctx.arc(r*0.12,0,r*0.32,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(r*0.22,0,r*0.12,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
    // HP-Bar (clean)
    const bw=r*2.4, bh=4, by=en.y-r-13;
    ctx.fillStyle='rgba(255,255,255,0.12)'; ctx.beginPath(); ctx.roundRect(en.x-bw/2,by,bw,bh,2); ctx.fill();
    ctx.fillStyle=en.type==='boss'?'#c77dff':'#4de0a0'; ctx.beginPath(); ctx.roundRect(en.x-bw/2,by,bw*Math.max(0,en.hp/en.maxHp),bh,2); ctx.fill();
  }
  // — Spieler —
  const skin=currentSkin(), SABER=skin.blade, SABER_CORE=skin.core;
  const angles=bladeAngles();
  // Nachleuchten jeder Klinge
  ctx.save(); ctx.translate(player.x,player.y);
  for(const a of angles){
    for(let i=1;i<=5;i++){
      ctx.save(); ctx.rotate(a - i*0.16);
      ctx.globalAlpha=0.12*(1-i/6); ctx.fillStyle=SABER;
      ctx.beginPath(); ctx.roundRect(player.radius, -2.5, bladeLen, 5, 2.5); ctx.fill();
      ctx.restore();
    }
  }
  ctx.restore();

  ctx.save(); ctx.translate(player.x,player.y);
  // Bodenschatten
  ctx.fillStyle='rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.ellipse(0,15,15,6,0,0,Math.PI*2); ctx.fill();
  // Schild
  if(Date.now()<shieldUntil){
    ctx.strokeStyle='rgba(124,200,255,0.9)'; ctx.lineWidth=2; ctx.shadowColor='#7cc8ff'; ctx.shadowBlur=16;
    ctx.beginPath(); ctx.arc(0,0,player.radius+13,0,Math.PI*2); ctx.stroke(); ctx.shadowBlur=0;
  }
  // Umhang
  ctx.fillStyle='#131c2e'; ctx.beginPath();
  ctx.moveTo(-11,-7); ctx.quadraticCurveTo(-16,6,-12,15); ctx.lineTo(12,15); ctx.quadraticCurveTo(16,6,11,-7); ctx.closePath(); ctx.fill();
  ctx.strokeStyle='rgba(124,180,255,0.18)'; ctx.lineWidth=1; ctx.stroke();
  // Torso
  ctx.fillStyle='#e9eef7'; ctx.beginPath(); ctx.roundRect(-9,-9,18,18,5); ctx.fill();
  ctx.fillStyle='#aab7cc'; ctx.beginPath(); ctx.roundRect(-9,-1,18,2.5,1); ctx.fill();
  // Kopf mit Kapuze
  ctx.fillStyle='#f2dcc0'; ctx.beginPath(); ctx.arc(0,-15,7.5,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#1a2438'; ctx.beginPath(); ctx.arc(0,-16,8.5,Math.PI*0.95,Math.PI*2.05); ctx.fill();
  // Plasmaklinge(n) – rotieren permanent
  for(const a of angles){
    ctx.save(); ctx.rotate(a);
    ctx.shadowColor=SABER; ctx.shadowBlur=20; ctx.fillStyle=SABER;
    ctx.beginPath(); ctx.roundRect(player.radius, -3, bladeLen, 6, 3); ctx.fill();
    ctx.shadowBlur=10; ctx.fillStyle=SABER_CORE;
    ctx.beginPath(); ctx.roundRect(player.radius+1, -1.2, bladeLen-5, 2.4, 1.2); ctx.fill();
    ctx.shadowBlur=0;
    // Griff
    ctx.fillStyle='#c2cbdb'; ctx.beginPath(); ctx.roundRect(4,-3,15,6,2); ctx.fill();
    ctx.fillStyle='#5d6b82'; ctx.beginPath(); ctx.rect(9,-3,2,6); ctx.fill(); ctx.beginPath(); ctx.rect(13,-3,2,6); ctx.fill();
    ctx.restore();
  }
  ctx.restore();
  // kreisende Splitter
  if(shards.length){
    ctx.save(); ctx.globalCompositeOperation='lighter';
    for(const s of shards){
      ctx.shadowColor='#9ad0ff'; ctx.shadowBlur=10; ctx.fillStyle='#bfe3ff';
      ctx.beginPath(); ctx.arc(s.x,s.y,4.5,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  }
  // particles (additiv = leuchtend)
  ctx.globalCompositeOperation='lighter';
  for(const p of particles){
    if(p.sword) continue;   // Blade-Trail wird direkt am Spieler gezeichnet
    ctx.globalAlpha=Math.max(0,p.life/(p.max||0.6));
    if(p.bolt){   // Kettenblitz: zackige Linie zwischen zwei Gegnern
      ctx.strokeStyle='#bfe3ff'; ctx.lineWidth=2; ctx.shadowColor='#9ad0ff'; ctx.shadowBlur=8;
      ctx.beginPath(); ctx.moveTo(p.x,p.y);
      const seg=4; for(let k=1;k<seg;k++){ const f=k/seg; ctx.lineTo(p.x+(p.x2-p.x)*f+(Math.random()-0.5)*10, p.y+(p.y2-p.y)*f+(Math.random()-0.5)*10); }
      ctx.lineTo(p.x2,p.y2); ctx.stroke(); ctx.shadowBlur=0; continue;
    }
    ctx.fillStyle=p.color; ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill();
  }
  ctx.globalCompositeOperation='source-over';
  ctx.globalAlpha=1;
  // floats
  ctx.font='800 13px system-ui'; ctx.textAlign='center';
  for(const f of floats){
    ctx.globalAlpha=Math.max(0,f.life/0.9);
    ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillText(f.text,f.x+1,f.y+1);
    ctx.fillStyle=f.color; ctx.fillText(f.text,f.x,f.y);
  }
  ctx.globalAlpha=1;
  ctx.restore();   // Welt-Ebene schließen

  // — Bildschirm-Ebene (folgt nicht der Kamera) —
  // Treffer-Blitz: kurzer roter Rand, wenn der Spieler getroffen wird
  if(Date.now()<flashUntil){
    const a=(flashUntil-Date.now())/140;
    const fg=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*0.3,w/2,h/2,Math.max(w,h)*0.7);
    fg.addColorStop(0,'rgba(255,40,40,0)'); fg.addColorStop(1,'rgba(255,30,30,'+(0.35*a).toFixed(3)+')');
    ctx.fillStyle=fg; ctx.fillRect(0,0,w,h);
  }
  // Große Ansage in der Mitte (Welle/Boss/Meilenstein)
  if(banner){
    const a=Math.min(1, banner.life*1.6), rise=(1-Math.min(1,banner.life/banner.max))*10;
    ctx.save(); ctx.globalAlpha=a; ctx.textAlign='center';
    ctx.fillStyle=banner.color; ctx.font='800 40px system-ui';
    ctx.shadowColor='rgba(0,0,0,0.6)'; ctx.shadowBlur=12;
    ctx.fillText(banner.title, w/2, h*0.30 - rise);
    if(banner.sub){ ctx.font='600 16px system-ui'; ctx.fillStyle='#cdd7e6'; ctx.fillText(banner.sub, w/2, h*0.30 + 24 - rise); }
    ctx.restore();
  }
  // Hinweise oben (Freischaltungen/Abzeichen), gestapelt
  if(toasts.length){
    ctx.save(); ctx.textAlign='center'; ctx.font='700 14px system-ui';
    for(let i=0;i<toasts.length;i++){
      const t=toasts[i], a=Math.min(1,t.life*1.4);
      const y=70+i*30;
      ctx.globalAlpha=a*0.9; ctx.fillStyle='rgba(10,18,32,0.9)';
      const tw=ctx.measureText(t.text).width+28;
      ctx.beginPath(); ctx.roundRect(w/2-tw/2, y-16, tw, 24, 12); ctx.fill();
      ctx.strokeStyle='rgba(110,200,255,0.5)'; ctx.lineWidth=1; ctx.stroke();
      ctx.globalAlpha=a; ctx.fillStyle='#e6edf7'; ctx.fillText(t.text, w/2, y);
    }
    ctx.restore();
  }
  ctx.restore();   // Shake schließen
}

function loop(t){
  raf=requestAnimationFrame(loop);
  if(!lastTime) lastTime=t;
  const dt=Math.min(50, t-lastTime); lastTime=t;
  if(state==='playing') update(dt);
  draw();
}
loop(performance.now());

// prevent context menu / selection
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('selectstart',e=>e.preventDefault());
